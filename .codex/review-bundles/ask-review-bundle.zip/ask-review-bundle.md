# Targeted Review: /ask Runtime Parity Safety

## Reviewer Instructions

Review this as a merge-gate code review. Focus only on correctness, data-loss risk, regression risk, security/privacy, maintainability, and missing failure-path tests.

Do not rewrite the implementation unless the diff is fundamentally unsafe. Return only merge-blocking findings and important test gaps.

## Decision Needed

Is the `/ask` runtime parity layer now on `main` safe enough to keep, or are there merge-blocking regressions?

## Pushed Code

- Repository: https://github.com/grahama1970/agent-skills
- Main branch: https://github.com/grahama1970/agent-skills/tree/main
- Commit under review: `a6634764`
- Compare base: `9810f934`
- Compare URL: https://github.com/grahama1970/agent-skills/compare/9810f934...a6634764

## Expected Safety Contract

1. Plain `/ask` degrades to no-op runtime artifacts if artifact writing is unavailable, unless a high-integrity mode explicitly requires artifacts.
2. Deep-review and integrity-sensitive paths fail closed when required runtime artifacts cannot be written.
3. Run IDs are one-run-one-directory; collisions are rejected by default unless overwrite/resume is explicit.
4. `status --prune` only removes validated `ask.runtime.v1` run directories and must not delete unrelated directories, malformed runs, or symlinks.
5. `status --watch` is bounded by timeout and exits for terminal states including `needs_attention`.
6. Dry-run produces deterministic spec/risk preview before mutation; it must not mutate the repo.
7. Review bundles stay selective; broad dirty-worktree dumps require explicit opt-in.

## Prior Critique Being Rechecked

1. Earlier review packets were too noisy and included generated artifacts.
2. Runtime critique flagged prune safety, unwritable artifact roots, `needs_attention.safe_default`, `ask_id` collisions, and unbounded watch.
3. The external reviewer should not need to infer intended behavior from the diff.

## Non-goals For This Review

- Do not review generated `.ask_artifacts` or old E2E outputs.
- Do not review pi-subagents feature parity beyond portable runtime contracts.
- Do not review unrelated skills except the included `$review-code` bundle command changes.

## Selected Review Files

- `skills/ask/src/ask/run_state.py`
- `skills/ask/src/ask/status.py`
- `skills/ask/src/ask/ask.py`
- `skills/ask/src/ask/doctor.py`
- `skills/ask/src/ask/runtime_schema.py`
- `skills/ask/src/ask/dry_run_spec.py`
- `skills/ask/src/ask/chain_specs.py`
- `skills/ask/src/ask/reviewer_specs.py`
- `skills/ask/tests/test_run_state_protocol.py`
- `skills/review-code/commands/bundle.py`
- `skills/review-code/commands/find.py`
- `skills/review-code/SKILL.md`

## Validation Already Run

- `python3 -m py_compile ...` passed for changed `/ask` modules.
- `uv run --project skills/ask pytest skills/ask/tests/test_run_state_protocol.py skills/ask/tests/test_runtime_discipline.py -q` passed: 42 tests.
- Broader adjacent `/ask` runtime/deep-review tests passed: 50 tests.
- `cd skills/ask && ./sanity.sh` passed.
- `git diff --check` passed before commit.

## Diff Stat

```text
 skills/ask/src/ask/ask.py                   | 241 +++++---
 skills/ask/src/ask/chain_specs.py           | 130 +++--
 skills/ask/src/ask/doctor.py                | 213 ++++---
 skills/ask/src/ask/dry_run_spec.py          | 139 +++++
 skills/ask/src/ask/reviewer_specs.py        | 120 ++--
 skills/ask/src/ask/run_state.py             | 869 ++++++++++++++++++++--------
 skills/ask/src/ask/runtime_schema.py        | 127 ++++
 skills/ask/src/ask/status.py                |  88 ++-
 skills/ask/tests/test_run_state_protocol.py | 580 +++++++++++++++++++
 skills/review-code/SKILL.md                 |  79 ++-
 skills/review-code/commands/bundle.py       | 582 ++++++++++++++-----
 skills/review-code/commands/find.py         |  72 +++
 12 files changed, 2585 insertions(+), 655 deletions(-)
```

## Selected Diff

```diff
diff --git a/skills/ask/src/ask/ask.py b/skills/ask/src/ask/ask.py
index 47240f19..1c146b63 100644
--- a/skills/ask/src/ask/ask.py
+++ b/skills/ask/src/ask/ask.py
@@ -26,7 +26,9 @@ from .ask_config import (
     DEFAULT_ORACLE_TIMEOUT,
     ORACLE_BACKENDS,
 )
+from .chain_specs import apply_chain_options
 from .deep_review import build_deep_review_request, infer_deep_review
+from .dry_run_spec import build_ask_dry_run_spec, print_execution_spec
 from .ask_oracle import _is_meta_item
 from .ask_persona_profiles import _format_persona_suggestion
 from .ask_relevance import _has_relevant_domain_items, _try_evidence_case
@@ -38,8 +40,9 @@ from .ask_routing import (
     _parse_natural_roundtable_query,
     _should_auto_oracle_persona,
 )
+from .reviewer_specs import focus_from_reviewer_specs, load_selected_reviewer_specs
 from .review_protocols import is_date_sensitive_question
-from .run_state import append_event, build_context_policy, complete_run, create_run
+from .run_state import AskRunState, NoopRunState, make_run_id
 from .session_writer import SessionWriter
 from .skills_exec import run_skill, parse_memory_output, run_memory_recall
 from .persona_routing import (
@@ -102,11 +105,7 @@ def ask(
     deep_review_fallback_policy: str = "fail_closed",
     deep_review_persist: str = "summary",
     deep_review_output_root: str = ".ask_artifacts/deep-review",
-    run_id: Optional[str] = None,
-    review_context: Optional[str] = None,
-    inherit_memory: Optional[str] = None,
-    inherit_skills: Optional[str] = None,
-    inherit_project_context: Optional[str] = None,
+    run_state: Optional[AskRunState] = None,
 ) -> dict:
     """Query accumulated knowledge.
 
@@ -152,37 +151,6 @@ def ask(
         dict with answer, sources, bridges.
     """
     started_at = time.time()
-    run_mode = "ask"
-    if deep_review:
-        run_mode = "deep-review"
-    elif roundtable:
-        run_mode = "roundtable"
-    elif parallel_review:
-        run_mode = "parallel-review"
-    elif oracle_model:
-        run_mode = "oracle"
-    context_policy = build_context_policy(
-        run_mode,
-        review_context=review_context,
-        inherit_memory=inherit_memory,
-        inherit_skills=inherit_skills,
-        inherit_project_context=inherit_project_context,
-    )
-    run_record = create_run(
-        run_mode,
-        question=question,
-        target=deep_review_target,
-        run_id=run_id,
-        metadata={
-            "scope": scope,
-            "oracle_backend": oracle_backend,
-            "oracle_model": oracle_model or "",
-            "oracle_reasoning": oracle_reasoning,
-            "dogpile_mode": dogpile_mode,
-            "context_policy": context_policy,
-        },
-    )
-    append_event(run_record["run_id"], run_mode, "context_policy_resolved", data=context_policy)
     session = SessionWriter(scope=scope, persona_id=persona_id)
     session.add_turn("user", question)
 
@@ -194,10 +162,6 @@ def ask(
         "answer": "",
         "auto_learned": False,
         "hybrid_mode": hybrid,
-        "run_id": run_record["run_id"],
-        "artifact_dir": run_record["artifact_dir"],
-        "run_mode": run_mode,
-        "context_policy": context_policy,
     }
     if oracle_model:
         result["oracle"] = {
@@ -237,6 +201,8 @@ def ask(
         result["oracle"]["dogpile_recommended"] = _should_use_dogpile(question, dogpile_mode)
     deep_review_request = None
     if deep_review:
+        if run_state:
+            run_state.step_started("deep_review_request", target=deep_review_target or "")
         deep_review_request = build_deep_review_request(
             question=question,
             explicit_target=deep_review_target,
@@ -255,9 +221,24 @@ def ask(
             "target": deep_review_request["target"],
             "persist": deep_review_persist,
         }
+        if run_state:
+            run_state.step_finished("deep_review_request", target=deep_review_request["target"])
+        if deep_review_request["target"].get("requires_target"):
+            attention = {
+                "reason": "missing_deep_review_target",
+                "question": deep_review_request["target"].get("message", "Deep review requires an explicit target."),
+                "safe_default": "do_not_run_review",
+                "resume_hint": "Run again with --deep-review-target <paths|diff|plan|artifact>.",
+            }
+            if run_state:
+                attention = run_state.needs_attention(**attention)
+            result["needs_attention"] = attention
+            return result
 
     # Step 1: Memory recall (hybrid or standard)
     if hybrid:
+        if run_state:
+            run_state.step_started("hybrid_recall", scope=scope, k=k)
         log.info("Hybrid querying memory: q=%r scope=%r k=%d", question, scope, k)
         hybrid_result = ask_hybrid(question, scope, k, use_bridges=use_bridges)
         result["items"] = hybrid_result["items"]
@@ -268,7 +249,11 @@ def ask(
             "Hybrid recall: %d QRA + %d RAG -> %d items",
             result.get("qra_count", 0), result.get("rag_count", 0), len(result["items"]),
         )
+        if run_state:
+            run_state.step_finished("hybrid_recall", items_count=len(result["items"]))
     else:
+        if run_state:
+            run_state.step_started("memory_recall", scope=scope, k=k)
         log.info("Querying memory: q=%r scope=%r k=%d", question, scope, k)
         recall_result = run_memory_recall(question, scope, k)
 
@@ -276,14 +261,20 @@ def ask(
             items = parse_memory_output(recall_result["stdout"])
             result["items"].extend(items)
             log.info("Direct recall: %d items found", len(items))
+            if run_state:
+                run_state.step_finished("memory_recall", returncode=0, items_count=len(items))
         else:
             log.warning(
                 "Memory recall failed: code=%d, stderr=%s",
                 recall_result["returncode"], recall_result["stderr"][:100],
             )
+            if run_state:
+                run_state.step_finished("memory_recall", returncode=recall_result["returncode"], error=recall_result["stderr"][:200])
 
         # Step 2: Bridge traversal (optional, standard mode only)
         if use_bridges:
+            if run_state:
+                run_state.step_started("bridge_traversal")
             bridges = extract_bridges(question)
             result["bridges_found"] = bridges
             log.info("Bridge traversal: found bridges %s", bridges)
@@ -306,6 +297,8 @@ def ask(
                     log.debug("Bridge %s: %d new items (from %d total)", bridge, added, len(bridge_items))
                 else:
                     log.warning("Bridge recall for %s failed: code=%d", bridge, bridge_result["returncode"])
+            if run_state:
+                run_state.step_finished("bridge_traversal", bridges=bridges, items_count=len(result["items"]))
 
     # Step 2b: Evidence-case fallback for non-trivial queries.
     # Fires when: (a) no results at all, OR (b) only meta/irrelevant results.
@@ -318,6 +311,8 @@ def ask(
     # content about satellites, not pipeline health data.
     is_operational = _is_operational_question(question)
     if (is_operational or not has_domain_answer) and not _is_direct_control_lookup(question):
+        if run_state:
+            run_state.step_started("evidence_case", operational=is_operational, has_domain_answer=has_domain_answer)
         evidence_result = _try_evidence_case(question, scope)
         if evidence_result:
             result["evidence_case"] = evidence_result
@@ -379,12 +374,20 @@ def ask(
                         })
             if evidence_items:
                 result["items"] = evidence_items  # Replace, don't append
+        if run_state:
+            run_state.step_finished("evidence_case", used=bool(evidence_result), items_count=len(result["items"]))
 
     # Step 2c: Auto-learn if still no domain results
     if not domain_items and auto_learn:
+        if run_state:
+            run_state.step_started("auto_learn", collection=collection)
         result = _auto_learn(result, question, scope, collection, k, use_bridges)
+        if run_state:
+            run_state.step_finished("auto_learn", items_count=len(result.get("items", [])), auto_learned=bool(result.get("auto_learned")))
 
     # Step 3: Synthesise answer
+    if run_state:
+        run_state.step_started("synthesis", oracle_enabled=oracle_model is not None, deep_review=deep_review)
     _synthesise(
         result,
         k,
@@ -417,12 +420,15 @@ def ask(
         parallel_review_role_preset=parallel_review_role_preset,
         deep_review_request=deep_review_request,
     )
-    append_event(
-        run_record["run_id"],
-        run_mode,
-        "synthesis_completed",
-        data={"items": len(result["items"]), "has_answer": bool(result.get("answer"))},
-    )
+    if run_state:
+        run_state.step_finished(
+            "synthesis",
+            answer_chars=len(str(result.get("answer", ""))),
+            items_count=len(result.get("items", [])),
+            deep_review_artifacts=result.get("deep_review", {}).get("artifact_paths", {}),
+        )
+        if result.get("deep_review", {}).get("artifact_paths"):
+            run_state.add_artifacts(result["deep_review"]["artifact_paths"])
 
     # Step 4: Learn-back for persona accumulation
     if persona_id and result["items"]:
@@ -438,6 +444,8 @@ def ask(
     session_path = session.write()
     if session_path:
         result["session_path"] = str(session_path)
+    if run_state:
+        run_state.event("session_written", session_path=result.get("session_path", ""))
 
     _record_ask_telemetry(
         result=result,
@@ -452,18 +460,6 @@ def ask(
         oracle_peer=oracle_peer,
         oracle_iterations=oracle_iterations,
     )
-    artifact_paths = []
-    if result.get("session_path"):
-        artifact_paths.append(result["session_path"])
-    if result.get("deep_review"):
-        artifact_paths.extend(result["deep_review"].get("artifact_paths", []))
-    complete_run(
-        run_record["run_id"],
-        run_mode,
-        artifact_paths=artifact_paths,
-        final_verdict=result.get("deep_review", {}).get("verdict", ""),
-        verifier_status=result.get("deep_review", {}).get("verifier_status", ""),
-    )
 
     return result
 
@@ -611,11 +607,13 @@ def main(
     deep_review_fallback_policy: str = typer.Option("fail_closed", help="Deep-review downgrade policy: fail_closed or warn"),
     deep_review_persist: str = typer.Option("summary", help="Deep-review persistence: summary or full"),
     deep_review_output_root: str = typer.Option(".ask_artifacts/deep-review", help="Deep-review artifact directory"),
-    run_id: Optional[str] = typer.Option(None, "--run-id", help="Explicit run id for artifact/status correlation"),
-    review_context: Optional[str] = typer.Option(None, "--review-context", help="Child context policy: fresh or fork"),
-    inherit_memory: Optional[str] = typer.Option(None, "--inherit-memory", help="Memory inheritance: yes, no, summary"),
-    inherit_skills: Optional[str] = typer.Option(None, "--inherit-skills", help="Skill inheritance: yes, no, selected"),
-    inherit_project_context: Optional[str] = typer.Option(None, "--inherit-project-context", help="Project context inheritance: yes or no"),
+    chain: Optional[str] = typer.Option(None, "--chain", help="Saved review chain spec name or path"),
+    reviewer_specs: Optional[list[str]] = typer.Option(None, "--reviewer-spec", help="Reviewer spec name or path (repeatable)"),
+    dry_run: bool = typer.Option(False, "--dry-run", help="Preview execution spec and risk analysis without mutation"),
+    ask_id: Optional[str] = typer.Option(None, "--ask-id", help="Stable runtime artifact id for this ask call"),
+    run_output_root: Optional[str] = typer.Option(None, "--run-output-root", help="Directory for ask runtime artifacts"),
+    overwrite_run: bool = typer.Option(False, "--overwrite", help="Replace an existing run directory for --ask-id"),
+    resume_run: bool = typer.Option(False, "--resume", help="Resume a non-terminal existing run directory for --ask-id"),
     debug: bool = typer.Option(False, help="Enable debug logging"),
 ):
     question, inferred_parallel_review, inferred_parallel_reviewers, inferred_parallel_focus = (
@@ -666,6 +664,32 @@ def main(
         if oracle_backend == DEFAULT_ORACLE_BACKEND:
             oracle_backend = "subagent-runner"
 
+    if chain:
+        chain_options = apply_chain_options({
+            "deep_review": deep_review,
+            "parallel_review": parallel_review,
+            "parallel_reviewers": parallel_reviewers,
+            "deep_reviewers": deep_reviewers,
+            "deep_review_focus": deep_review_focus,
+            "parallel_review_focus": parallel_review_focus,
+            "oracle_backend": oracle_backend,
+            "oracle_reasoning": oracle_reasoning,
+        }, chain)
+        deep_review = bool(chain_options.get("deep_review", deep_review))
+        parallel_review = bool(chain_options.get("parallel_review", parallel_review))
+        parallel_reviewers = int(chain_options.get("parallel_reviewers", parallel_reviewers))
+        deep_reviewers = int(chain_options.get("deep_reviewers", deep_reviewers))
+        deep_review_focus = chain_options.get("deep_review_focus", deep_review_focus)
+        parallel_review_focus = chain_options.get("parallel_review_focus", parallel_review_focus)
+        oracle_backend = str(chain_options.get("oracle_backend", oracle_backend))
+        oracle_reasoning = chain_options.get("oracle_reasoning", oracle_reasoning)
+
+    loaded_reviewer_specs = load_selected_reviewer_specs(reviewer_specs)
+    reviewer_focus = focus_from_reviewer_specs(loaded_reviewer_specs)
+    if reviewer_focus:
+        deep_review_focus = ",".join(filter(None, [deep_review_focus, reviewer_focus]))
+        parallel_review_focus = ",".join(filter(None, [parallel_review_focus, reviewer_focus]))
+
     if deep_review or infer_deep_review(question):
         deep_review = True
         oracle = True
@@ -733,6 +757,11 @@ def main(
             "Deep-review reviewers must be >= 1.",
             param_hint="--deep-reviewers",
         )
+    if overwrite_run and resume_run:
+        raise typer.BadParameter(
+            "Use either --overwrite or --resume, not both.",
+            param_hint="--overwrite",
+        )
     if oracle and oracle_idle_timeout < 30:
         raise typer.BadParameter(
             "Oracle idle timeout must be >= 30 seconds.",
@@ -761,6 +790,51 @@ def main(
             param_hint="--oracle",
         )
 
+    run_id = ask_id or make_run_id(question)
+    request_payload = {
+        "command": "ask",
+        "question": question,
+        "scope": scope,
+        "k": k,
+        "bridges": bridges,
+        "raw": raw,
+        "auto_learn": auto_learn,
+        "collection": collection,
+        "hybrid": hybrid,
+        "consult_personas": consult_personas,
+        "persona_scope": persona_scope,
+        "persona_id": persona_id,
+        "oracle": oracle,
+        "oracle_backend": oracle_backend,
+        "oracle_model": oracle_model if oracle else None,
+        "oracle_reasoning": oracle_reasoning,
+        "oracle_timeout": oracle_timeout,
+        "oracle_idle_timeout": oracle_idle_timeout,
+        "oracle_heartbeat_interval": oracle_heartbeat_interval,
+        "oracle_persona": oracle_persona,
+        "oracle_peer": oracle_peer,
+        "oracle_iterations": oracle_iterations,
+        "roundtable": roundtable,
+        "roundtable_personas": roundtable_personas,
+        "parallel_review": parallel_review,
+        "parallel_reviewers": parallel_reviewers,
+        "parallel_review_personas": parallel_review_personas,
+        "parallel_review_focus": parallel_review_focus,
+        "dogpile_mode": dogpile_mode,
+        "deep_review": deep_review,
+        "deep_review_target": deep_review_target,
+        "deep_review_profile": deep_review_profile,
+        "deep_reviewers": deep_reviewers,
+        "deep_review_focus": deep_review_focus,
+        "deep_review_output_root": deep_review_output_root,
+        "chain": chain,
+        "reviewer_specs": reviewer_specs or [],
+        "suggested_personas_count": 0,
+    }
+    if dry_run:
+        print_execution_spec(build_ask_dry_run_spec(request_payload), as_json=as_json)
+        raise typer.Exit(code=0)
+
     suggested_personas: list[dict] = []
     if consult_personas:
         bridges_for_personas = extract_bridges(question)
@@ -769,6 +843,23 @@ def main(
             bridges=bridges_for_personas,
             scope=persona_scope,
         )
+        request_payload["suggested_personas_count"] = len(suggested_personas)
+
+    require_runtime_artifacts = deep_review or parallel_review
+    try:
+        run_state = AskRunState(run_id, output_root=run_output_root, overwrite=overwrite_run, resume=resume_run)
+        run_state.write_request(request_payload)
+    except (FileExistsError, FileNotFoundError, ValueError) as exc:
+        raise typer.BadParameter(
+            f"{exc}. Use a unique --ask-id, --overwrite, or --resume.",
+            param_hint="--ask-id",
+        ) from exc
+    except OSError as exc:
+        if require_runtime_artifacts:
+            raise
+        typer.echo(f"Warning: Runtime artifacts disabled: {exc}", err=True)
+        run_state = NoopRunState(run_id, reason=str(exc))
+    run_state.event("ask_started")
 
     started_at = time.time()
     try:
@@ -815,11 +906,7 @@ def main(
             deep_review_fallback_policy=deep_review_fallback_policy,
             deep_review_persist=deep_review_persist,
             deep_review_output_root=deep_review_output_root,
-            run_id=run_id,
-            review_context=review_context,
-            inherit_memory=inherit_memory,
-            inherit_skills=inherit_skills,
-            inherit_project_context=inherit_project_context,
+            run_state=run_state,
         )
     except Exception as exc:
         _record_ask_telemetry(
@@ -842,6 +929,7 @@ def main(
             oracle_peer=oracle_peer,
             oracle_iterations=oracle_iterations,
         )
+        run_state.fail(exc)
         raise
 
     if consult_personas:
@@ -850,6 +938,21 @@ def main(
             print(suggestion)
             result["suggested_personas"] = suggested_personas
 
+    result["ask_id"] = run_state.ask_id
+    result["runtime_artifacts"] = run_state.artifacts
+    if result.get("needs_attention"):
+        if as_json:
+            print(json.dumps(result, indent=2, default=str))
+        else:
+            attention = result["needs_attention"]
+            print("\n-- /ask needs attention --")
+            print(f"   Reason: {attention.get('reason', 'unknown')}")
+            print(f"   Question: {attention.get('question', '')}")
+            if attention.get("resume_hint"):
+                print(f"   Resume: {attention['resume_hint']}")
+            print()
+        raise typer.Exit(code=2)
+    run_state.finish(result)
     sys.exit(0 if result["items"] else 1)
 
 
diff --git a/skills/ask/src/ask/chain_specs.py b/skills/ask/src/ask/chain_specs.py
index 4df88c7c..3d07d4ec 100644
--- a/skills/ask/src/ask/chain_specs.py
+++ b/skills/ask/src/ask/chain_specs.py
@@ -1,4 +1,4 @@
-"""Saved review-chain specs for /ask."""
+"""Saved review chain specs for deterministic /ask workflows."""
 
 from __future__ import annotations
 
@@ -7,59 +7,111 @@ from typing import Any
 
 import yaml
 
-from .run_state import ASK_ROOT
 
-DEFAULT_CHAIN_SPEC_DIR = ASK_ROOT / "docs" / "chains"
+SKILL_ROOT = Path(__file__).resolve().parents[2]
+CHAIN_DIR = SKILL_ROOT / "docs" / "chains"
 
+BUILTIN_CHAINS: dict[str, dict[str, Any]] = {
+    "deep-review-safety": {
+        "name": "deep-review-safety",
+        "description": "Read-only safety review with independent reviewers and deep-review artifacts.",
+        "ask_options": {
+            "deep_review": True,
+            "parallel_review": True,
+            "parallel_reviewers": 5,
+            "deep_reviewers": 5,
+            "deep_review_focus": "filesystem,fail-closed,tests,auditability,privacy",
+            "parallel_review_focus": "filesystem,fail-closed,tests,auditability,privacy",
+            "oracle_backend": "subagent-runner",
+            "oracle_reasoning": "xhigh",
+        },
+    }
+}
 
-def load_chain_specs(chain_dir: str | Path | None = None) -> dict[str, dict[str, Any]]:
-    directory = Path(chain_dir) if chain_dir else DEFAULT_CHAIN_SPEC_DIR
-    specs: dict[str, dict[str, Any]] = {}
-    if not directory.exists():
-        return specs
-    for path in sorted(directory.glob("*.chain.yaml")):
-        payload = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
-        if not isinstance(payload, dict):
-            raise ValueError(f"Chain spec must be a mapping: {path}")
-        name = str(payload.get("name") or path.name.removesuffix(".chain.yaml"))
-        specs[name] = {**payload, "name": name, "path": str(path)}
-    return specs
+
+def load_chain_specs(chain_dir: Path | str | None = None) -> dict[str, dict[str, Any]]:
+    """Load saved review-chain specs, including runtime option presets."""
+
+    directory = Path(chain_dir).expanduser() if chain_dir else CHAIN_DIR
+    chains: dict[str, dict[str, Any]] = {}
+    for path in sorted({*directory.glob("*.chain.yaml"), *directory.glob("*.yaml"), *directory.glob("*.yml")}):
+        spec = _load_yaml(path)
+        spec["path"] = str(path)
+        chains[str(spec["name"])] = spec
+    for name, spec in BUILTIN_CHAINS.items():
+        chains.setdefault(name, {**spec, "path": "builtin"})
+    return chains
 
 
 def validate_chain_spec(spec: dict[str, Any]) -> list[str]:
+    """Return validation errors for a saved chain spec."""
+
     errors: list[str] = []
-    if not spec.get("name"):
-        errors.append("missing name")
+    if not isinstance(spec.get("name"), str) or not spec["name"]:
+        errors.append("name is required")
+
+    if "ask_options" in spec:
+        if not isinstance(spec["ask_options"], dict):
+            errors.append("ask_options must be a mapping")
+        return errors
+
     stages = spec.get("stages")
     if not isinstance(stages, list) or not stages:
         errors.append("stages must be a non-empty list")
         return errors
-    seen = set()
+
     for index, stage in enumerate(stages):
         if not isinstance(stage, dict):
-            errors.append(f"stage {index} must be a mapping")
+            errors.append(f"stages[{index}] must be a mapping")
             continue
-        stage_name = stage.get("name")
-        if not stage_name:
-            errors.append(f"stage {index} missing name")
-        elif stage_name in seen:
-            errors.append(f"duplicate stage name: {stage_name}")
-        else:
-            seen.add(stage_name)
+        if not stage.get("name"):
+            errors.append(f"stages[{index}].name is required")
         if not stage.get("type"):
-            errors.append(f"stage {stage_name or index} missing type")
-        if "requires" in stage and not isinstance(stage["requires"], list):
-            errors.append(f"stage {stage_name or index} requires must be a list")
-        if "produces" in stage and not isinstance(stage["produces"], list):
-            errors.append(f"stage {stage_name or index} produces must be a list")
+            errors.append(f"stages[{index}].type is required")
     return errors
 
 
-def get_chain_spec(name: str, chain_dir: str | Path | None = None) -> dict[str, Any]:
-    specs = load_chain_specs(chain_dir)
-    if name not in specs:
-        raise KeyError(f"Unknown chain spec: {name}")
-    errors = validate_chain_spec(specs[name])
-    if errors:
-        raise ValueError(f"Invalid chain spec {name}: {', '.join(errors)}")
-    return specs[name]
+def get_chain_spec(name: str, chain_dir: Path | str | None = None) -> dict[str, Any]:
+    chains = load_chain_specs(chain_dir)
+    if name not in chains:
+        raise FileNotFoundError(f"Unknown /ask chain spec: {name}")
+    return chains[name]
+
+
+def load_chain_spec(name: str) -> dict[str, Any]:
+    candidate = Path(name).expanduser()
+    if candidate.exists():
+        return _load_yaml(candidate)
+    for suffix in (".chain.yaml", ".yaml", ".yml"):
+        path = CHAIN_DIR / f"{name}{suffix}"
+        if path.exists():
+            return _load_yaml(path)
+    if name in BUILTIN_CHAINS:
+        return dict(BUILTIN_CHAINS[name])
+    raise FileNotFoundError(f"Unknown /ask chain spec: {name}")
+
+
+def apply_chain_options(current: dict[str, Any], chain_name: str | None) -> dict[str, Any]:
+    if not chain_name:
+        return current
+    spec = load_chain_spec(chain_name)
+    options = dict(spec.get("ask_options", {}))
+    merged = dict(current)
+    for key, value in options.items():
+        if value is None:
+            continue
+        if key.endswith("reviewers"):
+            merged[key] = max(int(merged.get(key, 0) or 0), int(value))
+        elif not merged.get(key):
+            merged[key] = value
+    merged["chain"] = spec.get("name", chain_name)
+    merged["chain_spec"] = spec
+    return merged
+
+
+def _load_yaml(path: Path) -> dict[str, Any]:
+    data = yaml.safe_load(path.read_text()) or {}
+    if not isinstance(data, dict):
+        raise ValueError(f"Chain spec must be a mapping: {path}")
+    data.setdefault("name", path.stem)
+    return data
diff --git a/skills/ask/src/ask/doctor.py b/skills/ask/src/ask/doctor.py
index 6e2bf49b..26bcdf2b 100644
--- a/skills/ask/src/ask/doctor.py
+++ b/skills/ask/src/ask/doctor.py
@@ -1,10 +1,12 @@
-"""Preflight diagnostics for /ask."""
+"""Doctor checks for ask runtime infrastructure."""
 
 from __future__ import annotations
 
 import json
 import os
+import shutil
 import subprocess
+import sys
 from pathlib import Path
 from typing import Any
 
@@ -12,123 +14,152 @@ import typer
 
 from .chain_specs import load_chain_specs, validate_chain_spec
 from .reviewer_specs import load_reviewer_specs
-from .run_state import ASK_ROOT, artifact_root
+from .run_state import default_run_root
+from .runtime_schema import validate_runtime_tree
 
-app = typer.Typer(help="/ask doctor - Preflight /ask dependencies")
 
+app = typer.Typer(help="/ask doctor - Check runtime prerequisites")
 
-def _skill_path(name: str) -> Path:
-    return ASK_ROOT.parent / name / "run.sh"
+SKILL_ROOT = Path(__file__).resolve().parents[2]
+SKILLS_DIR = SKILL_ROOT.parent
+AGENT_SKILLS_DIR = SKILLS_DIR.parent / ".agent" / "skills"
 
 
-def _check_skill(name: str) -> dict[str, Any]:
-    path = _skill_path(name)
-    executable = path.exists() and os.access(path, os.X_OK)
-    return {
-        "name": f"skill:{name}",
-        "status": "pass" if executable else "warn",
-        "detail": str(path) if executable else f"missing or not executable: {path}",
-    }
+def _skill_path(name: str) -> Path | None:
+    for candidate in (SKILLS_DIR / name / "run.sh", AGENT_SKILLS_DIR / name / "run.sh"):
+        if candidate.exists():
+            return candidate
+    return None
+
 
+def _check(name: str, ok: bool, detail: str, severity: str = "error") -> dict[str, Any]:
+    return {"name": name, "ok": ok, "severity": severity, "detail": detail}
 
-def _check_git() -> dict[str, Any]:
+
+def _run_live_check(name: str, command: list[str], timeout: int = 10, severity: str = "warning") -> dict[str, Any]:
     try:
         result = subprocess.run(
-            ["git", "-C", str(ASK_ROOT), "status", "--short"],
-            text=True,
+            command,
             capture_output=True,
-            timeout=5,
-            check=False,
+            text=True,
+            timeout=timeout,
+            env={k: v for k, v in os.environ.items() if k != "VIRTUAL_ENV"},
         )
-    except Exception as exc:
-        return {"name": "git-status", "status": "fail", "detail": str(exc)}
-    return {
-        "name": "git-status",
-        "status": "pass" if result.returncode == 0 else "fail",
-        "detail": f"returncode={result.returncode}",
-    }
-
-
-def _check_artifact_root(root: str | None = None) -> dict[str, Any]:
+    except subprocess.TimeoutExpired:
+        return _check(name, False, f"timed out after {timeout}s", severity=severity)
+    except OSError as exc:
+        return _check(name, False, str(exc), severity=severity)
+    detail = f"exit={result.returncode}"
+    if result.stderr:
+        detail += f" stderr={result.stderr.strip()[:160]}"
+    return _check(name, result.returncode == 0, detail, severity=severity)
+
+
+def run_doctor(live: bool = False) -> dict[str, Any]:
+    checks: list[dict[str, Any]] = []
+    checks.append(_check("python_version", sys.version_info >= (3, 11), sys.version.split()[0]))
+    checks.append(_check("skill_root", SKILL_ROOT.exists(), str(SKILL_ROOT)))
+    checks.append(_check("run_sh", os.access(SKILL_ROOT / "run.sh", os.X_OK), str(SKILL_ROOT / "run.sh")))
+    checks.append(_check("uv", shutil.which("uv") is not None, shutil.which("uv") or "not found"))
+
+    run_root = default_run_root()
     try:
-        base = artifact_root(root)
-        base.mkdir(parents=True, exist_ok=True)
-        marker = base / ".doctor_check"
-        marker.write_text("ok\n", encoding="utf-8")
-        marker.unlink(missing_ok=True)
-        return {"name": "artifact-root", "status": "pass", "detail": str(base)}
-    except Exception as exc:
-        return {"name": "artifact-root", "status": "fail", "detail": str(exc)}
-
+        run_root.mkdir(parents=True, exist_ok=True)
+        probe = run_root / ".doctor-write"
+        probe.write_text("ok\n")
+        probe.unlink()
+        writable = True
+        detail = str(run_root)
+    except OSError as exc:
+        writable = False
+        detail = f"{run_root}: {exc}"
+    checks.append(_check("artifact-root", writable, detail))
+    checks.append(_check("artifact_root_writable", writable, detail))
+    schema_result = validate_runtime_tree(run_root)
+    checks.append(
+        _check(
+            "runtime_artifact_schema",
+            schema_result["ok"],
+            f"checked={schema_result['runs_checked']} invalid={len(schema_result['invalid_runs'])}",
+            severity="error",
+        )
+    )
 
-def _check_reviewers() -> dict[str, Any]:
     try:
-        specs = load_reviewer_specs()
+        reviewer_specs = load_reviewer_specs()
+        checks.append(_check("reviewer-specs", bool(reviewer_specs), f"loaded={len(reviewer_specs)}"))
     except Exception as exc:
-        return {"name": "reviewer-specs", "status": "fail", "detail": str(exc)}
-    required = {"evidence-auditor", "failure-mode", "test-proof", "complexity-minimizer"}
-    missing = sorted(required - set(specs))
-    if missing:
-        return {"name": "reviewer-specs", "status": "fail", "detail": f"missing: {', '.join(missing)}"}
-    return {"name": "reviewer-specs", "status": "pass", "detail": f"{len(specs)} specs loaded"}
+        checks.append(_check("reviewer-specs", False, str(exc)))
 
-
-def _check_chains() -> dict[str, Any]:
     try:
-        chains = load_chain_specs()
+        chain_specs = load_chain_specs()
+        errors = {
+            name: validation_errors
+            for name, spec in chain_specs.items()
+            if (validation_errors := validate_chain_spec(spec))
+        }
+        checks.append(_check("chain-specs", not errors, f"loaded={len(chain_specs)} invalid={len(errors)}"))
     except Exception as exc:
-        return {"name": "chain-specs", "status": "fail", "detail": str(exc)}
-    errors = []
-    for name, spec in chains.items():
-        for error in validate_chain_spec(spec):
-            errors.append(f"{name}: {error}")
-    required = {"deep-review", "parallel-review"}
-    missing = sorted(required - set(chains))
-    if missing:
-        errors.append(f"missing: {', '.join(missing)}")
-    if errors:
-        return {"name": "chain-specs", "status": "fail", "detail": "; ".join(errors)}
-    return {"name": "chain-specs", "status": "pass", "detail": f"{len(chains)} chains loaded"}
-
-
-def run_doctor(*, artifact_root_override: str | None = None) -> dict[str, Any]:
-    checks = [
-        _check_skill("memory"),
-        _check_skill("dogpile"),
-        _check_skill("scillm"),
-        _check_skill("subagent-runner"),
-        _check_skill("monitor-personas"),
-        _check_artifact_root(artifact_root_override),
-        _check_git(),
-        _check_reviewers(),
-        _check_chains(),
-    ]
-    status = "pass"
-    if any(check["status"] == "fail" for check in checks):
-        status = "fail"
-    elif any(check["status"] == "warn" for check in checks):
-        status = "warn"
+        checks.append(_check("chain-specs", False, str(exc)))
+
+    for skill in ("memory", "dogpile", "scillm", "subagent-runner"):
+        path = _skill_path(skill)
+        checks.append(
+            _check(
+                f"skill:{skill}",
+                path is not None and os.access(path, os.X_OK),
+                str(path) if path else "not found",
+                severity="warning" if skill in {"dogpile", "scillm", "subagent-runner"} else "error",
+            )
+        )
+
+    checks.append(_check("ASK_RUN_OUTPUT_DIR", True, os.environ.get("ASK_RUN_OUTPUT_DIR", str(run_root)), "info"))
+    checks.append(_check("ASK_ORACLE_BACKEND", True, os.environ.get("ASK_ORACLE_BACKEND", "auto"), "info"))
+    checks.append(_check("ASK_ORACLE_MODEL", True, os.environ.get("ASK_ORACLE_MODEL", "gpt-5.5"), "info"))
+
+    if live:
+        memory = _skill_path("memory")
+        dogpile = _skill_path("dogpile")
+        scillm = _skill_path("scillm")
+        runner = _skill_path("subagent-runner")
+        if memory:
+            checks.append(_run_live_check("live:memory", [str(memory), "recall", "--q", "ask doctor live", "--k", "1"], timeout=15, severity="error"))
+        if dogpile:
+            checks.append(_run_live_check("live:dogpile", [str(dogpile), "--help"], timeout=10))
+        if scillm:
+            checks.append(_run_live_check("live:scillm", [str(scillm), "warm-check", "--json"], timeout=15))
+        if runner:
+            checks.append(_run_live_check("live:subagent-runner", [str(runner), "--help"], timeout=10))
+
+    error_count = sum(1 for check in checks if not check["ok"] and check["severity"] == "error")
+    warning_count = sum(1 for check in checks if not check["ok"] and check["severity"] == "warning")
     return {
-        "status": status,
-        "artifact_root": str(artifact_root(artifact_root_override)),
+        "status": "pass" if error_count == 0 else "fail",
+        "error_count": error_count,
+        "warning_count": warning_count,
+        "skill_root": str(SKILL_ROOT),
+        "run_root": str(run_root),
+        "runtime_schema": schema_result,
         "checks": checks,
     }
 
 
 @app.command()
 def main(
-    as_json: bool = typer.Option(False, "--json", help="Emit JSON"),
-    artifact_root_override: str | None = typer.Option(None, "--artifact-root", help="Override artifact root"),
+    as_json: bool = typer.Option(False, "--json", help="JSON output"),
+    live: bool = typer.Option(False, "--live", help="Run live subprocess/service checks"),
 ) -> None:
-    report = run_doctor(artifact_root_override=artifact_root_override)
+    result = run_doctor(live=live)
     if as_json:
-        print(json.dumps(report, indent=2, sort_keys=True))
-        raise typer.Exit(code=0 if report["status"] != "fail" else 1)
-
-    print(f"/ask doctor: {report['status']}")
-    for check in report["checks"]:
-        print(f"- {check['status'].upper():4} {check['name']}: {check['detail']}")
-    raise typer.Exit(code=0 if report["status"] != "fail" else 1)
+        print(json.dumps(result, indent=2, sort_keys=True))
+        raise typer.Exit(0 if result["status"] == "pass" else 1)
+
+    print(f"/ask doctor: {result['status']}")
+    print(f"artifact root: {result['run_root']}")
+    for check in result["checks"]:
+        mark = "ok" if check["ok"] else check["severity"]
+        print(f"  {mark:7} {check['name']}: {check['detail']}")
+    raise typer.Exit(0 if result["status"] == "pass" else 1)
 
 
 if __name__ == "__main__":
diff --git a/skills/ask/src/ask/dry_run_spec.py b/skills/ask/src/ask/dry_run_spec.py
new file mode 100644
index 00000000..fa17b405
--- /dev/null
+++ b/skills/ask/src/ask/dry_run_spec.py
@@ -0,0 +1,139 @@
+"""Deterministic dry-run execution specs for /ask commands."""
+
+from __future__ import annotations
+
+import json
+from datetime import datetime, timezone
+from typing import Any
+
+
+def build_execution_spec(
+    *,
+    command: str,
+    subject: str,
+    options: dict[str, Any],
+    planned_steps: list[str],
+    external_calls: list[str],
+    filesystem_writes: list[str],
+    memory_writes: list[str],
+    risk_notes: list[str],
+) -> dict[str, Any]:
+    return {
+        "dry_run": True,
+        "spec_protocol_version": "ask.dry_run.v1",
+        "generated_at": datetime.now(timezone.utc).isoformat(),
+        "command": command,
+        "subject": subject,
+        "options": options,
+        "planned_steps": planned_steps,
+        "risk_analysis": {
+            "external_calls": external_calls,
+            "filesystem_writes": filesystem_writes,
+            "memory_writes": memory_writes,
+            "notes": risk_notes,
+        },
+        "mutation_policy": "no runtime artifacts, memory writes, subprocess mutations, or oracle calls are performed in dry-run",
+    }
+
+
+def build_ask_dry_run_spec(request: dict[str, Any]) -> dict[str, Any]:
+    external_calls = ["memory recall"]
+    filesystem_writes: list[str] = []
+    memory_writes: list[str] = []
+    risk_notes = ["ordinary ask dry-run exits before request/status/events artifacts are written"]
+    if request.get("auto_learn"):
+        external_calls.extend(["dogpile discovery", "ingest-youtube", "fetcher", "extractor"])
+        memory_writes.append("learned QRA/persona items")
+    if request.get("oracle"):
+        external_calls.append(f"oracle backend: {request.get('oracle_backend')}")
+    if request.get("deep_review"):
+        external_calls.append("deep-review reviewers")
+        filesystem_writes.append(str(request.get("deep_review_output_root") or ".ask_artifacts/deep-review"))
+        risk_notes.append("deep review is integrity-sensitive and requires runtime artifacts during real execution")
+    if request.get("parallel_review"):
+        external_calls.append("parallel reviewer fanout")
+    if request.get("dogpile_mode") == "force":
+        external_calls.append("dogpile forced freshness search")
+    return build_execution_spec(
+        command="ask",
+        subject=str(request.get("question", "")),
+        options=request,
+        planned_steps=[
+            "route natural language options",
+            "write runtime request/status/events artifacts",
+            "recall memory",
+            "optionally traverse bridges or build evidence case",
+            "optionally auto-learn, dogpile, oracle, parallel-review, or deep-review",
+            "synthesize answer",
+            "finish runtime status",
+        ],
+        external_calls=external_calls,
+        filesystem_writes=filesystem_writes,
+        memory_writes=memory_writes,
+        risk_notes=risk_notes,
+    )
+
+
+def build_learn_dry_run_spec(request: dict[str, Any]) -> dict[str, Any]:
+    return build_execution_spec(
+        command="learn",
+        subject=str(request.get("topic", "")),
+        options=request,
+        planned_steps=[
+            "detect persona/topic",
+            "check existing memory",
+            "discover sources through dogpile/discover-books/feed/arxiv",
+            "ingest selected videos/books/web pages",
+            "extract QRA triples",
+            "store learned items",
+        ],
+        external_calls=["memory recall", "dogpile", "discover-books", "ingest-youtube", "fetcher", "extractor"],
+        filesystem_writes=["session transcript", "task-monitor state", "runtime request/status/events artifacts"],
+        memory_writes=["persona profile", "QRA triples", "learning session summary"],
+        risk_notes=["real learn may run multi-minute external discovery and ingestion"],
+    )
+
+
+def build_nightly_dry_run_spec(request: dict[str, Any]) -> dict[str, Any]:
+    return build_execution_spec(
+        command="nightly",
+        subject=str(request.get("persona") or request.get("scope", "")),
+        options=request,
+        planned_steps=[
+            "discover persona profiles",
+            "search for new persona content",
+            "ingest new items",
+            "optionally refresh OS knowledge",
+            "store updates",
+        ],
+        external_calls=["memory recall", "ingest-youtube search", "arxiv search"],
+        filesystem_writes=["runtime request/status/events artifacts"],
+        memory_writes=["new persona QRA items", "updated persona profile"],
+        risk_notes=["real nightly may touch many personas unless --persona narrows scope"],
+    )
+
+
+def build_os_learn_dry_run_spec(request: dict[str, Any]) -> dict[str, Any]:
+    return build_execution_spec(
+        command="os learn",
+        subject=str(request.get("depth", "")),
+        options=request,
+        planned_steps=[
+            "crawl skill manifests",
+            "crawl packages and configuration",
+            "build capability graph",
+            "generate OS QRA triples",
+            "store OS knowledge",
+        ],
+        external_calls=["memory learn during real execution"],
+        filesystem_writes=["runtime request/status/events artifacts"],
+        memory_writes=["scope=os QRA triples"],
+        risk_notes=["real os learn reads local repo files and writes memory records"],
+    )
+
+
+def print_execution_spec(spec: dict[str, Any], as_json: bool = False) -> None:
+    if as_json:
+        print(json.dumps(spec, indent=2, sort_keys=True, default=str))
+        return
+    print(json.dumps(spec, indent=2, sort_keys=True, default=str))
diff --git a/skills/ask/src/ask/reviewer_specs.py b/skills/ask/src/ask/reviewer_specs.py
index 1de7354e..1dca865f 100644
--- a/skills/ask/src/ask/reviewer_specs.py
+++ b/skills/ask/src/ask/reviewer_specs.py
@@ -1,4 +1,4 @@
-"""Reviewer-role frontmatter specs for /ask protocols."""
+"""Reviewer role specs for /ask review workflows."""
 
 from __future__ import annotations
 
@@ -8,9 +8,9 @@ from typing import Any
 
 import yaml
 
-from .run_state import ASK_ROOT
 
-DEFAULT_REVIEWER_SPEC_DIR = ASK_ROOT / "docs" / "reviewers"
+SKILL_ROOT = Path(__file__).resolve().parents[2]
+REVIEWER_DIR = SKILL_ROOT / "docs" / "reviewers"
 
 FOCUS_ALIASES = {
     "auditability": "evidence-auditor",
@@ -27,7 +27,6 @@ FOCUS_ALIASES = {
     "security": "security-data-risk",
     "data-risk": "security-data-risk",
 }
-
 DEFAULT_DYNAMIC_ORDER = [
     "evidence-auditor",
     "failure-mode",
@@ -36,32 +35,72 @@ DEFAULT_DYNAMIC_ORDER = [
     "complexity-minimizer",
     "security-data-risk",
 ]
+BUILTIN_REVIEWERS: dict[str, dict[str, Any]] = {
+    "security": {
+        "name": "security",
+        "protocol_role": "security_reviewer",
+        "focus": ["data-loss", "path-validation", "secret-persistence", "fail-closed"],
+    },
+    "qa": {
+        "name": "qa",
+        "protocol_role": "test_reviewer",
+        "focus": ["failure-path-tests", "cli-behavior", "regression-risk"],
+    },
+    "runtime": {
+        "name": "runtime",
+        "protocol_role": "runtime_reviewer",
+        "focus": ["state-machine", "events", "watch", "resume", "prune"],
+    },
+}
 
 
-def _split_frontmatter(text: str, path: Path) -> tuple[dict[str, Any], str]:
-    match = re.match(r"^---\n(.*?)\n---\n(.*)$", text, flags=re.DOTALL)
-    if not match:
-        raise ValueError(f"Reviewer spec missing YAML frontmatter: {path}")
-    metadata = yaml.safe_load(match.group(1)) or {}
-    if not isinstance(metadata, dict):
-        raise ValueError(f"Reviewer spec frontmatter must be a mapping: {path}")
-    return metadata, match.group(2).strip()
+def load_reviewer_spec(name: str) -> dict[str, Any]:
+    candidate = Path(name).expanduser()
+    if candidate.exists():
+        return _load_yaml(candidate)
+    for suffix in (".yaml", ".yml"):
+        path = REVIEWER_DIR / f"{name}{suffix}"
+        if path.exists():
+            return _load_yaml(path)
+    specs = load_reviewer_specs()
+    key = FOCUS_ALIASES.get(name.strip().lower(), name.strip())
+    if key in specs:
+        return specs[key]
+    if name in BUILTIN_REVIEWERS:
+        return dict(BUILTIN_REVIEWERS[name])
+    raise FileNotFoundError(f"Unknown /ask reviewer spec: {name}")
+
+
+def load_selected_reviewer_specs(names: list[str] | None) -> list[dict[str, Any]]:
+    return [load_reviewer_spec(name) for name in names or []]
+
+
+def focus_from_reviewer_specs(specs: list[dict[str, Any]]) -> str:
+    focus: list[str] = []
+    for spec in specs:
+        values = spec.get("focus", [])
+        if isinstance(values, str):
+            values = [value.strip() for value in values.split(",")]
+        for value in values:
+            if value and value not in focus:
+                focus.append(str(value))
+    return ",".join(focus)
 
 
 def load_reviewer_specs(spec_dir: str | Path | None = None) -> dict[str, dict[str, Any]]:
-    directory = Path(spec_dir) if spec_dir else DEFAULT_REVIEWER_SPEC_DIR
+    directory = Path(spec_dir) if spec_dir else REVIEWER_DIR
     specs: dict[str, dict[str, Any]] = {}
-    if not directory.exists():
-        return specs
-    for path in sorted(directory.glob("*.md")):
-        metadata, prompt = _split_frontmatter(path.read_text(encoding="utf-8"), path)
-        name = str(metadata.get("name") or path.stem)
-        specs[name] = {
-            **metadata,
-            "name": name,
-            "prompt": prompt,
-            "path": str(path),
-        }
+    if directory.exists():
+        for path in sorted(directory.glob("*.md")):
+            metadata, prompt = _split_frontmatter(path.read_text(encoding="utf-8"), path)
+            name = str(metadata.get("name") or path.stem)
+            specs[name] = {**metadata, "name": name, "prompt": prompt, "path": str(path)}
+        for path in sorted([*directory.glob("*.yaml"), *directory.glob("*.yml")]):
+            data = _load_yaml(path)
+            name = str(data.get("name") or path.stem)
+            specs.setdefault(name, data)
+    for name, spec in BUILTIN_REVIEWERS.items():
+        specs.setdefault(name, dict(spec))
     return specs
 
 
@@ -73,11 +112,6 @@ def get_reviewer_spec(name: str, spec_dir: str | Path | None = None) -> dict[str
     return specs[key]
 
 
-def _append_unique(names: list[str], name: str) -> None:
-    if name not in names:
-        names.append(name)
-
-
 def select_reviewer_angles(
     question: str,
     *,
@@ -88,11 +122,9 @@ def select_reviewer_angles(
     specs = load_reviewer_specs(spec_dir)
     if not specs:
         return []
-
     selected: list[str] = []
     for item in [part.strip().lower() for part in (focus or "").split(",") if part.strip()]:
         _append_unique(selected, FOCUS_ALIASES.get(item, item))
-
     lowered = question.lower()
     _append_unique(selected, "evidence-auditor")
     _append_unique(selected, "failure-mode")
@@ -103,10 +135,8 @@ def select_reviewer_angles(
     if any(term in lowered for term in ["security", "secret", "credential", "memory", "data"]):
         _append_unique(selected, "security-data-risk")
     _append_unique(selected, "complexity-minimizer")
-
     for name in DEFAULT_DYNAMIC_ORDER:
         _append_unique(selected, name)
-
     resolved = [specs[name] for name in selected if name in specs]
     return resolved[: max(1, count)]
 
@@ -125,3 +155,27 @@ def spec_to_participant(spec: dict[str, Any], *, turn_index: int = 0) -> dict[st
             if key in spec
         },
     }
+
+
+def _split_frontmatter(text: str, path: Path) -> tuple[dict[str, Any], str]:
+    match = re.match(r"^---\n(.*?)\n---\n(.*)$", text, flags=re.DOTALL)
+    if not match:
+        raise ValueError(f"Reviewer spec missing YAML frontmatter: {path}")
+    metadata = yaml.safe_load(match.group(1)) or {}
+    if not isinstance(metadata, dict):
+        raise ValueError(f"Reviewer spec frontmatter must be a mapping: {path}")
+    return metadata, match.group(2).strip()
+
+
+def _append_unique(names: list[str], name: str) -> None:
+    if name not in names:
+        names.append(name)
+
+
+def _load_yaml(path: Path) -> dict[str, Any]:
+    data = yaml.safe_load(path.read_text()) or {}
+    if not isinstance(data, dict):
+        raise ValueError(f"Reviewer spec must be a mapping: {path}")
+    data.setdefault("name", path.stem)
+    data.setdefault("path", str(path))
+    return data
diff --git a/skills/ask/src/ask/run_state.py b/skills/ask/src/ask/run_state.py
index 5bca334e..ef8247b7 100644
--- a/skills/ask/src/ask/run_state.py
+++ b/skills/ask/src/ask/run_state.py
@@ -1,296 +1,691 @@
-"""Runtime state and artifact helpers for /ask."""
+"""Runtime artifacts for ask executions."""
 
 from __future__ import annotations
 
 import json
 import os
+import re
+import secrets
+import shutil
 import time
 from datetime import datetime, timezone
 from pathlib import Path
 from typing import Any
 
-ASK_ROOT = Path(__file__).resolve().parents[2]
-DEFAULT_ARTIFACT_ROOT = ASK_ROOT / ".ask_artifacts"
-
-VALID_REVIEW_CONTEXTS = {"fresh", "fork"}
-VALID_INHERIT_MEMORY = {"yes", "no", "summary"}
-VALID_INHERIT_SKILLS = {"yes", "no", "selected"}
-VALID_INHERIT_PROJECT_CONTEXT = {"yes", "no"}
-
-NEEDS_ATTENTION_STATES = {
-    "needs_target",
-    "needs_repo_access",
-    "needs_model_fallback",
-    "needs_memory_health",
-    "needs_freshness_confirmation",
-    "needs_verifier_fix",
-    "stalled_no_heartbeat",
-    "stalled_no_artifact_progress",
-}
-
-DEFAULT_CONTEXT_POLICIES: dict[str, dict[str, Any]] = {
-    "ask": {
-        "review_context": "fresh",
-        "inherit_memory": "yes",
-        "inherit_skills": "selected",
-        "inherit_project_context": "no",
-        "memory_as_evidence": False,
-    },
-    "oracle": {
-        "review_context": "fresh",
-        "inherit_memory": "summary",
-        "inherit_skills": "selected",
-        "inherit_project_context": "no",
-        "memory_as_evidence": False,
-    },
-    "parallel-review": {
-        "review_context": "fresh",
-        "inherit_memory": "summary",
-        "inherit_skills": "selected",
-        "inherit_project_context": "no",
-        "memory_as_evidence": False,
-    },
-    "roundtable": {
-        "review_context": "fresh",
-        "inherit_memory": "summary",
-        "inherit_skills": "selected",
-        "inherit_project_context": "no",
-        "memory_as_evidence": False,
-    },
-    "deep-review": {
-        "review_context": "fresh",
-        "inherit_memory": "summary",
-        "inherit_skills": "selected",
-        "inherit_project_context": "no",
-        "memory_as_evidence": False,
-    },
-    "review-and-fix": {
-        "review_context": "fork",
-        "inherit_memory": "summary",
-        "inherit_skills": "selected",
-        "inherit_project_context": "yes",
-        "memory_as_evidence": False,
-        "requires_worktree": True,
-    },
-}
-
-
-def utc_now() -> str:
-    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
-
-
-def new_run_id(mode: str) -> str:
-    safe_mode = "".join(ch if ch.isalnum() else "-" for ch in mode.lower()).strip("-") or "ask"
-    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
-    return f"{stamp}-{safe_mode}-{os.getpid()}-{int(time.time() * 1000) % 100000:05d}"
-
-
-def artifact_root(root: str | Path | None = None) -> Path:
-    path = Path(root) if root else DEFAULT_ARTIFACT_ROOT
-    if not path.is_absolute():
-        path = ASK_ROOT / path
-    return path
-
-
-def mode_artifact_dir(mode: str, run_id: str, root: str | Path | None = None) -> Path:
-    return artifact_root(root) / mode / run_id
-
-
-def _write_json(path: Path, payload: dict[str, Any]) -> None:
-    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
-
-
-def _read_json(path: Path) -> dict[str, Any]:
-    return json.loads(path.read_text(encoding="utf-8"))
+from .runtime_schema import RUNTIME_PROTOCOL_VERSION
 
 
-def create_run(
-    mode: str,
-    *,
-    question: str = "",
-    target: str | None = None,
-    run_id: str | None = None,
-    metadata: dict[str, Any] | None = None,
-    root: str | Path | None = None,
-) -> dict[str, Any]:
-    resolved_run_id = run_id or new_run_id(mode)
-    run_dir = mode_artifact_dir(mode, resolved_run_id, root=root)
-    run_dir.mkdir(parents=True, exist_ok=True)
-    request = {
-        "run_id": resolved_run_id,
-        "mode": mode,
-        "question": question,
-        "target": target or "",
-        "artifact_dir": str(run_dir),
-        "created_at": utc_now(),
-        "metadata": metadata or {},
-    }
-    status = {
-        "run_id": resolved_run_id,
-        "mode": mode,
-        "state": "running",
-        "started_at": request["created_at"],
-        "updated_at": request["created_at"],
-        "last_heartbeat": request["created_at"],
-        "artifact_dir": str(run_dir),
-        "verifier_status": "",
-        "final_verdict": "",
-        "needs_attention": "",
-        "failure_reason": "",
-        "artifact_paths": [],
-    }
-    _write_json(run_dir / "request.json", request)
-    _write_json(run_dir / "status.json", status)
-    append_event(resolved_run_id, mode, "run_started", root=root, data={"target": target or ""})
-    return {**request, "status": status}
+SKILL_ROOT = Path(__file__).resolve().parents[2]
+DEFAULT_RUN_ROOT = SKILL_ROOT / ".ask_artifacts" / "runs"
+DEFAULT_ARTIFACT_ROOT = SKILL_ROOT / ".ask_artifacts"
+RUN_ID_RE = re.compile(r"[^A-Za-z0-9_.-]+")
+TERMINAL_STATES = {"answered", "completed", "no_results", "failed", "cancelled", "needs_attention"}
+RESUMABLE_STATES = {"created", "running"}
+INDEX_FILENAME = "index.jsonl"
+
+
+def default_run_root() -> Path:
+    return Path(os.environ.get("ASK_RUN_OUTPUT_DIR", str(DEFAULT_RUN_ROOT))).expanduser()
+
+
+def safe_run_id(value: str) -> str:
+    cleaned = RUN_ID_RE.sub("-", value.strip()).strip("-._")
+    return cleaned or "ask-run"
+
+
+def make_run_id(question: str) -> str:
+    import hashlib
+
+    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
+    digest = hashlib.sha256(question.encode("utf-8")).hexdigest()[:8]
+    return f"ask-{stamp}-{digest}-{secrets.token_hex(4)}"
+
+
+def atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
+    path.parent.mkdir(parents=True, exist_ok=True)
+    tmp = path.with_suffix(path.suffix + ".tmp")
+    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True, default=str) + "\n")
+    tmp.replace(path)
+
+
+def artifact_root(root: Path | str | None = None) -> Path:
+    if root is not None:
+        return Path(root).expanduser()
+    return Path(os.environ.get("ASK_ARTIFACT_ROOT", str(DEFAULT_ARTIFACT_ROOT))).expanduser()
+
+
+def new_run_id(mode: str = "ask") -> str:
+    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
+    return safe_run_id(f"{mode}-{stamp}-{secrets.token_hex(4)}")
+
+
+def mode_artifact_dir(mode: str, run_id: str, root: Path | str | None = None) -> Path:
+    return artifact_root(root) / safe_run_id(mode) / safe_run_id(run_id)
+
+
+def _mode_events_path(run_id: str, mode: str, root: Path | str | None = None) -> Path:
+    return mode_artifact_dir(mode, run_id, root) / "events.jsonl"
 
 
 def append_event(
     run_id: str,
     mode: str,
     event: str,
-    *,
     data: dict[str, Any] | None = None,
-    root: str | Path | None = None,
+    root: Path | str | None = None,
+    **fields: Any,
 ) -> None:
-    run_dir = mode_artifact_dir(mode, run_id, root=root)
-    run_dir.mkdir(parents=True, exist_ok=True)
-    with (run_dir / "events.jsonl").open("a", encoding="utf-8") as handle:
-        handle.write(json.dumps({"time": utc_now(), "event": event, "data": data or {}}, sort_keys=True) + "\n")
+    payload = {
+        "ts": datetime.now(timezone.utc).isoformat(),
+        "run_id": safe_run_id(run_id),
+        "mode": safe_run_id(mode),
+        "event": event,
+        **(data or {}),
+        **fields,
+    }
+    events_path = _mode_events_path(run_id, mode, root)
+    events_path.parent.mkdir(parents=True, exist_ok=True)
+    with events_path.open("a", encoding="utf-8") as handle:
+        handle.write(json.dumps(payload, sort_keys=True, default=str) + "\n")
+
+
+def write_status(run_id: str, mode: str, state: str, root: Path | str | None = None, **fields: Any) -> dict[str, Any]:
+    run_dir = mode_artifact_dir(mode, run_id, root)
+    payload = {
+        "run_id": safe_run_id(run_id),
+        "mode": safe_run_id(mode),
+        "state": state,
+        "updated_at": datetime.now(timezone.utc).isoformat(),
+        "artifacts": {
+            "run_dir": str(run_dir),
+            "request": str(run_dir / "request.json"),
+            "status": str(run_dir / "status.json"),
+            "events": str(run_dir / "events.jsonl"),
+        },
+        **fields,
+    }
+    atomic_write_json(run_dir / "status.json", payload)
+    return payload
 
 
-def write_status(
-    run_id: str,
+def create_run(
     mode: str,
-    *,
-    root: str | Path | None = None,
-    **updates: Any,
+    question: str = "",
+    run_id: str | None = None,
+    root: Path | str | None = None,
+    context_policy: dict[str, Any] | None = None,
+    **fields: Any,
 ) -> dict[str, Any]:
-    run_dir = mode_artifact_dir(mode, run_id, root=root)
-    status_path = run_dir / "status.json"
-    status = _read_json(status_path) if status_path.exists() else {"run_id": run_id, "mode": mode}
-    status.update(updates)
-    status["updated_at"] = utc_now()
-    if "last_heartbeat" not in updates:
-        status["last_heartbeat"] = status["updated_at"]
-    _write_json(status_path, status)
-    return status
+    actual_run_id = safe_run_id(run_id or new_run_id(mode))
+    actual_mode = safe_run_id(mode)
+    run_dir = mode_artifact_dir(actual_mode, actual_run_id, root)
+    run_dir.mkdir(parents=True, exist_ok=True)
+    request = {
+        "run_id": actual_run_id,
+        "mode": actual_mode,
+        "question": question,
+        "created_at": datetime.now(timezone.utc).isoformat(),
+        "context_policy": context_policy or build_context_policy(actual_mode),
+        **fields,
+    }
+    atomic_write_json(run_dir / "request.json", request)
+    status = write_status(actual_run_id, actual_mode, "running", root=root, question=question)
+    append_event(actual_run_id, actual_mode, "created", root=root, question=question)
+    return {
+        "run_id": actual_run_id,
+        "mode": actual_mode,
+        "run_dir": str(run_dir),
+        "request_path": str(run_dir / "request.json"),
+        "status_path": str(run_dir / "status.json"),
+        "events_path": str(run_dir / "events.jsonl"),
+        "request": request,
+        "status": status,
+    }
 
 
 def complete_run(
     run_id: str,
     mode: str,
-    *,
     artifact_paths: list[str] | None = None,
-    final_verdict: str = "",
-    verifier_status: str = "",
-    root: str | Path | None = None,
+    root: Path | str | None = None,
+    **fields: Any,
 ) -> dict[str, Any]:
-    append_event(run_id, mode, "run_completed", root=root, data={"final_verdict": final_verdict})
-    return write_status(
+    payload = write_status(
         run_id,
         mode,
+        "completed",
         root=root,
-        state="completed",
-        completed_at=utc_now(),
+        completed_at=datetime.now(timezone.utc).isoformat(),
         artifact_paths=artifact_paths or [],
-        final_verdict=final_verdict,
-        verifier_status=verifier_status,
-        needs_attention="",
+        **fields,
     )
+    append_event(run_id, mode, "completed", root=root, artifact_paths=artifact_paths or [])
+    return payload
 
 
-def fail_run(
-    run_id: str,
-    mode: str,
-    reason: str,
-    *,
-    needs_attention: str = "",
-    root: str | Path | None = None,
-) -> dict[str, Any]:
-    if needs_attention and needs_attention not in NEEDS_ATTENTION_STATES:
-        raise ValueError(f"Unknown needs-attention state: {needs_attention}")
-    append_event(run_id, mode, "run_failed", root=root, data={"reason": reason, "needs_attention": needs_attention})
-    return write_status(
-        run_id,
-        mode,
-        root=root,
-        state="failed",
-        failed_at=utc_now(),
-        failure_reason=reason,
-        needs_attention=needs_attention,
-    )
+def fail_run(run_id: str, mode: str, error: str, root: Path | str | None = None) -> dict[str, Any]:
+    payload = write_status(run_id, mode, "failed", root=root, error=error)
+    append_event(run_id, mode, "failed", root=root, error=error)
+    return payload
 
 
-def _iter_status_files(root: str | Path | None = None) -> list[Path]:
-    base = artifact_root(root)
-    if not base.exists():
-        return []
-    return sorted(base.glob("*/*/status.json"), key=lambda path: path.stat().st_mtime, reverse=True)
+def _read_mode_run(status_path: Path) -> dict[str, Any] | None:
+    try:
+        status = json.loads(status_path.read_text())
+        request_path = status_path.with_name("request.json")
+        events_path = status_path.with_name("events.jsonl")
+        request = json.loads(request_path.read_text()) if request_path.exists() else {}
+        events = read_event_tail(events_path, 1000)
+    except (OSError, json.JSONDecodeError):
+        return None
+    return {
+        "run_id": status.get("run_id", status_path.parent.name),
+        "mode": status.get("mode", status_path.parent.parent.name),
+        "run_dir": str(status_path.parent),
+        "request": request,
+        "status": status,
+        "events": events,
+    }
 
 
-def list_runs(*, last: int = 10, mode: str | None = None, root: str | Path | None = None) -> list[dict[str, Any]]:
-    runs = []
-    for status_path in _iter_status_files(root):
-        status = _read_json(status_path)
-        if mode and status.get("mode") != mode:
-            continue
-        runs.append(status)
-        if len(runs) >= last:
-            break
-    return runs
-
-
-def get_run(run_id: str, *, root: str | Path | None = None) -> dict[str, Any] | None:
-    for status_path in _iter_status_files(root):
-        status = _read_json(status_path)
-        if status.get("run_id") == run_id:
-            request_path = status_path.parent / "request.json"
-            return {"status": status, "request": _read_json(request_path) if request_path.exists() else {}}
+def get_run(run_id: str, root: Path | str | None = None) -> dict[str, Any] | None:
+    base = artifact_root(root)
+    safe_id = safe_run_id(run_id)
+    for status_path in sorted(base.glob(f"*/{safe_id}/status.json")):
+        loaded = _read_mode_run(status_path)
+        if loaded:
+            return loaded
     return None
 
 
 def build_context_policy(
     mode: str,
     *,
-    review_context: str | None = None,
-    inherit_memory: str | None = None,
-    inherit_skills: str | None = None,
-    inherit_project_context: str | None = None,
+    review_context: str = "fresh",
+    inherit_memory: str = "summary",
+    inherit_skills: str = "selected",
+    inherit_project_context: str = "no",
+    memory_as_evidence: bool | None = None,
 ) -> dict[str, Any]:
-    policy = dict(DEFAULT_CONTEXT_POLICIES.get(mode, DEFAULT_CONTEXT_POLICIES["ask"]))
-    if review_context is not None:
-        if review_context not in VALID_REVIEW_CONTEXTS:
-            raise ValueError(f"review_context must be one of {sorted(VALID_REVIEW_CONTEXTS)}")
-        policy["review_context"] = review_context
-    if inherit_memory is not None:
-        if inherit_memory not in VALID_INHERIT_MEMORY:
-            raise ValueError(f"inherit_memory must be one of {sorted(VALID_INHERIT_MEMORY)}")
-        policy["inherit_memory"] = inherit_memory
-    if inherit_skills is not None:
-        if inherit_skills not in VALID_INHERIT_SKILLS:
-            raise ValueError(f"inherit_skills must be one of {sorted(VALID_INHERIT_SKILLS)}")
-        policy["inherit_skills"] = inherit_skills
-    if inherit_project_context is not None:
-        if inherit_project_context not in VALID_INHERIT_PROJECT_CONTEXT:
-            raise ValueError(f"inherit_project_context must be one of {sorted(VALID_INHERIT_PROJECT_CONTEXT)}")
-        policy["inherit_project_context"] = inherit_project_context
-    policy["mode"] = mode
-    return policy
-
-
-def review_and_fix_policy(target: str, *, worktree: str | None = None) -> dict[str, Any]:
+    use_memory_as_evidence = bool(memory_as_evidence) if memory_as_evidence is not None else inherit_memory == "full"
+    return {
+        "mode": mode,
+        "review_context": review_context,
+        "inherit_memory": inherit_memory,
+        "inherit_skills": inherit_skills,
+        "inherit_project_context": inherit_project_context,
+        "memory_as_evidence": use_memory_as_evidence,
+    }
+
+
+def review_and_fix_policy(target: str, worktree: str | None = None) -> dict[str, Any]:
     if not worktree:
         return {
-            "allowed": False,
             "target": target,
+            "allowed": False,
             "needs_attention": "needs_repo_access",
-            "reason": "review-and-fix lanes require an explicit isolated worktree",
+            "safe_default": "review_only",
+            "resume_hint": "Provide an isolated worktree for review-and-fix.",
         }
     return {
-        "allowed": True,
         "target": target,
         "worktree": worktree,
-        "needs_attention": "",
+        "allowed": True,
         "write_policy": "isolated_worktree_only",
     }
+
+
+class AskRunState:
+    """Append-only event log plus atomic status/request artifacts for one ask run."""
+
+    def __init__(
+        self,
+        ask_id: str,
+        output_root: Path | str | None = None,
+        *,
+        overwrite: bool = False,
+        resume: bool = False,
+    ) -> None:
+        self.ask_id = safe_run_id(ask_id)
+        self.output_root = Path(output_root).expanduser() if output_root else default_run_root()
+        self.run_dir = self.output_root / self.ask_id
+        self.request_path = self.run_dir / f"{self.ask_id}.request.json"
+        self.status_path = self.run_dir / f"{self.ask_id}.status.json"
+        self.events_path = self.run_dir / f"{self.ask_id}.events.jsonl"
+        self.started_at = datetime.now(timezone.utc).isoformat()
+        self.state = "created"
+        if resume and overwrite:
+            raise ValueError("Use either resume or overwrite, not both")
+        if resume:
+            if not self.run_dir.exists():
+                raise FileNotFoundError(f"Run does not exist for resume: {self.run_dir}")
+            state = self._existing_status_state()
+            if state not in RESUMABLE_STATES:
+                raise FileExistsError(f"Run is not resumable: {self.run_dir} state={state or 'unknown'}")
+        if self.run_dir.exists() and not overwrite and not resume:
+            raise FileExistsError(f"Run already exists: {self.run_dir}")
+        if overwrite and self.run_dir.exists():
+            if self.run_dir.is_symlink():
+                raise FileExistsError(f"Refusing to overwrite symlinked run dir: {self.run_dir}")
+            shutil.rmtree(self.run_dir)
+        self.run_dir.mkdir(parents=True, exist_ok=resume)
+
+    @property
+    def artifacts(self) -> dict[str, str]:
+        return {
+            "request": str(self.request_path),
+            "status": str(self.status_path),
+            "events": str(self.events_path),
+            "run_dir": str(self.run_dir),
+        }
+
+    def write_request(self, payload: dict[str, Any]) -> None:
+        request = {
+            "ask_id": self.ask_id,
+            "created_at": self.started_at,
+            "runtime_protocol_version": RUNTIME_PROTOCOL_VERSION,
+            **payload,
+        }
+        atomic_write_json(self.request_path, request)
+        self.event("request_written")
+        self.update("running", request=request)
+
+    def step_started(self, name: str, **fields: Any) -> None:
+        self.event(f"{name}_started", **fields)
+        self.update("running", current_step=name, **fields)
+
+    def step_finished(self, name: str, **fields: Any) -> None:
+        self.event(f"{name}_finished", **fields)
+        self.update("running", current_step=name, **fields)
+
+    def event(self, event_type: str, **fields: Any) -> None:
+        payload = {
+            "ts": datetime.now(timezone.utc).isoformat(),
+            "ask_id": self.ask_id,
+            "event": event_type,
+            **fields,
+        }
+        self.events_path.parent.mkdir(parents=True, exist_ok=True)
+        with self.events_path.open("a", encoding="utf-8") as handle:
+            handle.write(json.dumps(payload, sort_keys=True, default=str) + "\n")
+
+    def add_artifacts(self, artifacts: dict[str, Any]) -> None:
+        payload = self._read_current_status()
+        merged = dict(payload.get("artifacts", self.artifacts))
+        for key, value in artifacts.items():
+            if value:
+                merged[key] = str(value)
+        payload["artifacts"] = merged
+        payload["updated_at"] = datetime.now(timezone.utc).isoformat()
+        atomic_write_json(self.status_path, payload)
+        self.event("artifacts_registered", artifacts={k: str(v) for k, v in artifacts.items() if v})
+
+    def update(self, state: str, **fields: Any) -> None:
+        self.state = state
+        current = self._read_current_status()
+        artifacts = dict(self.artifacts)
+        artifacts.update(current.get("artifacts", {}))
+        payload = {
+            "ask_id": self.ask_id,
+            "state": state,
+            "started_at": self.started_at,
+            "updated_at": datetime.now(timezone.utc).isoformat(),
+            "runtime_protocol_version": RUNTIME_PROTOCOL_VERSION,
+            "artifacts": artifacts,
+            **fields,
+        }
+        if "needs_attention" in current and "needs_attention" not in payload:
+            payload["needs_attention"] = current["needs_attention"]
+        atomic_write_json(self.status_path, payload)
+        self._append_index(payload)
+
+    def needs_attention(
+        self,
+        *,
+        reason: str,
+        question: str,
+        safe_default: str = "pause",
+        resume_hint: str = "",
+        **fields: Any,
+    ) -> dict[str, Any]:
+        payload = {
+            "reason": reason,
+            "question": question,
+            "safe_default": safe_default,
+            "resume_hint": resume_hint,
+            **fields,
+        }
+        self.event("needs_attention", **payload)
+        self.update("needs_attention", needs_attention=payload)
+        return payload
+
+    def finish(self, result: dict[str, Any], state: str | None = None) -> None:
+        final_state = state or ("answered" if result.get("items") else "no_results")
+        summary = {
+            "question": result.get("question", ""),
+            "scope": result.get("scope", ""),
+            "items_count": len(result.get("items", [])),
+            "auto_learned": bool(result.get("auto_learned")),
+            "oracle_enabled": bool(result.get("oracle")),
+            "deep_review_enabled": bool(result.get("deep_review")),
+            "session_path": result.get("session_path", ""),
+        }
+        self.event("finished", state=final_state, **summary)
+        self.update(final_state, result_summary=summary)
+
+    def fail(self, exc: BaseException) -> None:
+        error = {"type": type(exc).__name__, "message": str(exc)}
+        self.event("failed", error=error)
+        self.update("failed", error=error)
+
+    def _read_current_status(self) -> dict[str, Any]:
+        if not self.status_path.exists():
+            return {
+                "ask_id": self.ask_id,
+                "state": self.state,
+                "started_at": self.started_at,
+                "runtime_protocol_version": RUNTIME_PROTOCOL_VERSION,
+                "artifacts": self.artifacts,
+            }
+        try:
+            return json.loads(self.status_path.read_text())
+        except (OSError, json.JSONDecodeError):
+            return {
+                "ask_id": self.ask_id,
+                "state": self.state,
+                "started_at": self.started_at,
+                "runtime_protocol_version": RUNTIME_PROTOCOL_VERSION,
+                "artifacts": self.artifacts,
+            }
+
+    def _existing_status_state(self) -> str | None:
+        if not self.status_path.exists():
+            return None
+        try:
+            payload = json.loads(self.status_path.read_text())
+        except (OSError, json.JSONDecodeError):
+            return None
+        state = payload.get("state")
+        return str(state) if state else None
+
+    def _append_index(self, status_payload: dict[str, Any]) -> None:
+        entry = {
+            "ts": datetime.now(timezone.utc).isoformat(),
+            "ask_id": self.ask_id,
+            "state": status_payload.get("state", self.state),
+            "command": status_payload.get("request", {}).get("command", "ask"),
+            "question": status_payload.get("request", {}).get("question", ""),
+            "started_at": status_payload.get("started_at", self.started_at),
+            "updated_at": status_payload.get("updated_at", ""),
+            "status_path": str(self.status_path),
+            "_status_path": str(self.status_path),
+            "run_dir": str(self.run_dir),
+        }
+        index_path = self.output_root / INDEX_FILENAME
+        index_path.parent.mkdir(parents=True, exist_ok=True)
+        with index_path.open("a", encoding="utf-8") as handle:
+            handle.write(json.dumps(entry, sort_keys=True, default=str) + "\n")
+
+
+class NoopRunState:
+    """Drop-in run-state used when artifact persistence is unavailable."""
+
+    disabled = True
+
+    def __init__(self, ask_id: str, reason: str = "") -> None:
+        self.ask_id = safe_run_id(ask_id)
+        self.reason = reason
+        self.state = "disabled"
+
+    @property
+    def artifacts(self) -> dict[str, str]:
+        return {"runtime_artifacts": "disabled", "reason": self.reason}
+
+    def write_request(self, payload: dict[str, Any]) -> None:
+        return None
+
+    def step_started(self, name: str, **fields: Any) -> None:
+        return None
+
+    def step_finished(self, name: str, **fields: Any) -> None:
+        return None
+
+    def event(self, event_type: str, **fields: Any) -> None:
+        return None
+
+    def add_artifacts(self, artifacts: dict[str, Any]) -> None:
+        return None
+
+    def update(self, state: str, **fields: Any) -> None:
+        self.state = state
+
+    def needs_attention(
+        self,
+        *,
+        reason: str,
+        question: str,
+        safe_default: str = "pause",
+        resume_hint: str = "",
+        **fields: Any,
+    ) -> dict[str, Any]:
+        return {
+            "reason": reason,
+            "question": question,
+            "safe_default": safe_default,
+            "resume_hint": resume_hint,
+            **fields,
+        }
+
+    def finish(self, result: dict[str, Any], state: str | None = None) -> None:
+        self.state = state or ("answered" if result.get("items") else "no_results")
+
+    def fail(self, exc: BaseException) -> None:
+        self.state = "failed"
+
+
+def resolve_run_target(target: str, output_root: Path | str | None = None) -> Path:
+    path = Path(target).expanduser()
+    if path.exists():
+        if path.is_dir():
+            matches = sorted(path.glob("*.status.json"))
+            if matches:
+                return matches[-1]
+        return path
+
+    root = Path(output_root).expanduser() if output_root else default_run_root()
+    run_dir = root / safe_run_id(target)
+    matches = sorted(run_dir.glob("*.status.json"))
+    if matches:
+        return matches[-1]
+    return run_dir / f"{safe_run_id(target)}.status.json"
+
+
+def read_status(target: str, tail_events: int = 0, output_root: Path | str | None = None) -> dict[str, Any]:
+    status_path = resolve_run_target(target, output_root)
+    if not status_path.exists():
+        raise FileNotFoundError(f"Run status not found: {target}")
+    payload = json.loads(status_path.read_text())
+    if tail_events > 0:
+        events_path = Path(payload.get("artifacts", {}).get("events", ""))
+        payload["event_tail"] = read_event_tail(events_path, tail_events)
+    return payload
+
+
+def read_event_tail(events_path: Path, limit: int) -> list[dict[str, Any]]:
+    if not events_path.exists():
+        return []
+    lines = events_path.read_text().splitlines()[-limit:]
+    events = []
+    for line in lines:
+        try:
+            events.append(json.loads(line))
+        except json.JSONDecodeError:
+            events.append({"event": "unparseable_event", "raw": line})
+    return events
+
+
+def watch_status(
+    target: str,
+    interval: float = 1.0,
+    tail_events: int = 5,
+    timeout_seconds: float = 300,
+    output_root: Path | str | None = None,
+) -> None:
+    last_state = None
+    deadline = time.time() + timeout_seconds
+    while True:
+        payload = read_status(target, tail_events=tail_events, output_root=output_root)
+        state = payload.get("state", "unknown")
+        if state != last_state:
+            print(json.dumps(payload, indent=2, sort_keys=True, default=str))
+            last_state = state
+        if state in TERMINAL_STATES:
+            return
+        if time.time() >= deadline:
+            raise TimeoutError(f"Timed out watching /ask run '{target}' after {timeout_seconds:g}s")
+        time.sleep(interval)
+
+
+def list_runs(
+    output_root: Path | str | None = None,
+    limit: int = 20,
+    *,
+    root: Path | str | None = None,
+    last: int | None = None,
+    mode: str | None = None,
+) -> list[dict[str, Any]]:
+    if root is not None or last is not None or mode is not None:
+        return _list_mode_runs(root=root, limit=last or limit, mode=mode)
+    run_root = Path(output_root).expanduser() if output_root else default_run_root()
+    if not run_root.exists():
+        return _list_mode_runs(root=None, limit=limit) if output_root is None else []
+    indexed = _list_runs_from_index(run_root, limit=limit)
+    if indexed:
+        runs = indexed[:limit]
+        if output_root is None:
+            runs.extend(_list_mode_runs(root=None, limit=limit))
+            runs.sort(key=lambda item: str(item.get("updated_at") or item.get("ts") or ""), reverse=True)
+        return runs[:limit]
+    statuses: list[dict[str, Any]] = []
+    for status_path in run_root.glob("*/*.status.json"):
+        try:
+            payload = json.loads(status_path.read_text())
+        except (OSError, json.JSONDecodeError):
+            continue
+        payload["_status_path"] = str(status_path)
+        statuses.append(payload)
+    if output_root is None:
+        statuses.extend(_list_mode_runs(root=None, limit=limit))
+    statuses.sort(key=lambda item: str(item.get("updated_at") or item.get("started_at") or ""), reverse=True)
+    return statuses[:limit]
+
+
+def _list_mode_runs(root: Path | str | None = None, limit: int = 20, mode: str | None = None) -> list[dict[str, Any]]:
+    base = artifact_root(root)
+    if not base.exists():
+        return []
+    pattern = f"{safe_run_id(mode)}/*/status.json" if mode else "*/status.json"
+    status_paths = list(base.glob(pattern)) if mode else list(base.glob("*/*/status.json"))
+    runs: list[dict[str, Any]] = []
+    for status_path in status_paths:
+        loaded = _read_mode_run(status_path)
+        if not loaded:
+            continue
+        status = loaded["status"]
+        runs.append(
+            {
+                "run_id": loaded["run_id"],
+                "mode": loaded["mode"],
+                "state": status.get("state", ""),
+                "updated_at": status.get("updated_at", ""),
+                "run_dir": loaded["run_dir"],
+                "status": status,
+            }
+        )
+    runs.sort(key=lambda item: str(item.get("updated_at", "")), reverse=True)
+    return runs[:limit]
+
+
+def _list_runs_from_index(root: Path, limit: int = 20) -> list[dict[str, Any]]:
+    index_path = root / INDEX_FILENAME
+    if not index_path.exists():
+        return []
+    latest: dict[str, dict[str, Any]] = {}
+    for line in index_path.read_text().splitlines():
+        try:
+            entry = json.loads(line)
+        except json.JSONDecodeError:
+            continue
+        ask_id = str(entry.get("ask_id", ""))
+        status_path = Path(str(entry.get("status_path", "")))
+        if not ask_id or not status_path.exists():
+            continue
+        latest[ask_id] = entry
+    runs = sorted(latest.values(), key=lambda item: str(item.get("updated_at") or item.get("ts") or ""), reverse=True)
+    return runs[:limit]
+
+
+def _validated_run_status(run_dir: Path) -> dict[str, Any] | None:
+    if run_dir.is_symlink():
+        return None
+    status_path = run_dir / f"{run_dir.name}.status.json"
+    if not status_path.is_file():
+        return None
+    try:
+        payload = json.loads(status_path.read_text())
+    except (OSError, json.JSONDecodeError):
+        return None
+    if payload.get("runtime_protocol_version") != RUNTIME_PROTOCOL_VERSION:
+        return None
+    if payload.get("ask_id") != run_dir.name:
+        return None
+    artifact_run_dir = payload.get("artifacts", {}).get("run_dir")
+    if not artifact_run_dir:
+        return None
+    try:
+        if Path(artifact_run_dir).expanduser().resolve() != run_dir.resolve():
+            return None
+    except OSError:
+        return None
+    return payload
+
+
+def prune_runs(output_root: Path | str | None = None, older_than_days: int = 14, dry_run: bool = False) -> dict[str, Any]:
+
+    root = Path(output_root).expanduser() if output_root else default_run_root()
+    root = root.resolve()
+    cutoff = time.time() - older_than_days * 24 * 60 * 60
+    removed: list[str] = []
+    kept: list[str] = []
+    if not root.exists():
+        return {"run_root": str(root), "older_than_days": older_than_days, "dry_run": dry_run, "removed": [], "kept": []}
+    for run_dir in sorted(path for path in root.iterdir() if path.is_dir() or path.is_symlink()):
+        try:
+            resolved_parent = run_dir.resolve().parent
+        except OSError:
+            kept.append(str(run_dir))
+            continue
+        if resolved_parent != root:
+            kept.append(str(run_dir))
+            continue
+        if _validated_run_status(run_dir) is None:
+            kept.append(str(run_dir))
+            continue
+        try:
+            mtime = run_dir.stat().st_mtime
+        except OSError:
+            kept.append(str(run_dir))
+            continue
+        if mtime >= cutoff:
+            kept.append(str(run_dir))
+            continue
+        removed.append(str(run_dir))
+        if not dry_run:
+            shutil.rmtree(run_dir)
+    return {
+        "run_root": str(root),
+        "older_than_days": older_than_days,
+        "dry_run": dry_run,
+        "removed": removed,
+        "kept": kept,
+    }
diff --git a/skills/ask/src/ask/runtime_schema.py b/skills/ask/src/ask/runtime_schema.py
new file mode 100644
index 00000000..795f8e65
--- /dev/null
+++ b/skills/ask/src/ask/runtime_schema.py
@@ -0,0 +1,127 @@
+"""Runtime protocol schema helpers for /ask artifacts."""
+
+from __future__ import annotations
+
+import json
+from pathlib import Path
+from typing import Any
+
+
+RUNTIME_PROTOCOL_VERSION = "ask.runtime.v1"
+REQUEST_REQUIRED = {"ask_id", "created_at", "runtime_protocol_version"}
+STATUS_REQUIRED = {"ask_id", "state", "started_at", "updated_at", "runtime_protocol_version", "artifacts"}
+EVENT_REQUIRED = {"ts", "ask_id", "event"}
+
+
+def runtime_schema_summary() -> dict[str, Any]:
+    return {
+        "runtime_protocol_version": RUNTIME_PROTOCOL_VERSION,
+        "request": {"required": sorted(REQUEST_REQUIRED)},
+        "status": {"required": sorted(STATUS_REQUIRED)},
+        "event": {"required": sorted(EVENT_REQUIRED)},
+    }
+
+
+def validate_request(payload: dict[str, Any]) -> list[str]:
+    errors = _missing_errors("request", payload, REQUEST_REQUIRED)
+    if payload.get("runtime_protocol_version") != RUNTIME_PROTOCOL_VERSION:
+        errors.append("request.runtime_protocol_version must be ask.runtime.v1")
+    return errors
+
+
+def validate_status(payload: dict[str, Any]) -> list[str]:
+    errors = _missing_errors("status", payload, STATUS_REQUIRED)
+    if payload.get("runtime_protocol_version") != RUNTIME_PROTOCOL_VERSION:
+        errors.append("status.runtime_protocol_version must be ask.runtime.v1")
+    artifacts = payload.get("artifacts")
+    if not isinstance(artifacts, dict):
+        errors.append("status.artifacts must be an object")
+    else:
+        for key in ("request", "status", "events", "run_dir"):
+            if not artifacts.get(key):
+                errors.append(f"status.artifacts.{key} is required")
+    needs_attention = payload.get("needs_attention")
+    if payload.get("state") == "needs_attention" and not isinstance(needs_attention, dict):
+        errors.append("status.needs_attention must be present for needs_attention state")
+    if isinstance(needs_attention, dict):
+        for key in ("reason", "question", "safe_default", "resume_hint"):
+            if key not in needs_attention:
+                errors.append(f"status.needs_attention.{key} is required")
+    return errors
+
+
+def validate_event(payload: dict[str, Any], line_no: int | None = None) -> list[str]:
+    prefix = f"event[{line_no}]" if line_no is not None else "event"
+    errors = _missing_errors(prefix, payload, EVENT_REQUIRED)
+    if not isinstance(payload.get("event", ""), str):
+        errors.append(f"{prefix}.event must be a string")
+    return errors
+
+
+def validate_run_dir(run_dir: Path) -> dict[str, Any]:
+    ask_id = run_dir.name
+    request_path = run_dir / f"{ask_id}.request.json"
+    status_path = run_dir / f"{ask_id}.status.json"
+    events_path = run_dir / f"{ask_id}.events.jsonl"
+    errors: list[str] = []
+
+    request_payload = _read_json_file(request_path, errors, "request")
+    status_payload = _read_json_file(status_path, errors, "status")
+    if request_payload is not None:
+        errors.extend(validate_request(request_payload))
+        if request_payload.get("ask_id") != ask_id:
+            errors.append("request.ask_id must match run directory name")
+    if status_payload is not None:
+        errors.extend(validate_status(status_payload))
+        if status_payload.get("ask_id") != ask_id:
+            errors.append("status.ask_id must match run directory name")
+
+    if not events_path.exists():
+        errors.append("events file is missing")
+    else:
+        for line_no, line in enumerate(events_path.read_text().splitlines(), 1):
+            try:
+                event = json.loads(line)
+            except json.JSONDecodeError:
+                errors.append(f"event[{line_no}] is not valid JSON")
+                continue
+            errors.extend(validate_event(event, line_no=line_no))
+            if event.get("ask_id") != ask_id:
+                errors.append(f"event[{line_no}].ask_id must match run directory name")
+
+    return {"run_dir": str(run_dir), "ok": not errors, "errors": errors}
+
+
+def validate_runtime_tree(root: Path) -> dict[str, Any]:
+    results = []
+    if root.exists():
+        for run_dir in sorted(path for path in root.iterdir() if path.is_dir() and not path.is_symlink()):
+            if (run_dir / f"{run_dir.name}.status.json").exists():
+                results.append(validate_run_dir(run_dir))
+    invalid = [result for result in results if not result["ok"]]
+    return {
+        "root": str(root),
+        "schema": runtime_schema_summary(),
+        "runs_checked": len(results),
+        "invalid_runs": invalid,
+        "ok": not invalid,
+    }
+
+
+def _missing_errors(prefix: str, payload: dict[str, Any], required: set[str]) -> list[str]:
+    return [f"{prefix}.{key} is required" for key in sorted(required) if key not in payload]
+
+
+def _read_json_file(path: Path, errors: list[str], label: str) -> dict[str, Any] | None:
+    if not path.exists():
+        errors.append(f"{label} file is missing")
+        return None
+    try:
+        payload = json.loads(path.read_text())
+    except json.JSONDecodeError as exc:
+        errors.append(f"{label} file is invalid JSON: {exc}")
+        return None
+    if not isinstance(payload, dict):
+        errors.append(f"{label} file must contain a JSON object")
+        return None
+    return payload
diff --git a/skills/ask/src/ask/status.py b/skills/ask/src/ask/status.py
index ab2093f3..9397f545 100644
--- a/skills/ask/src/ask/status.py
+++ b/skills/ask/src/ask/status.py
@@ -14,10 +14,11 @@ import os
 import subprocess
 import sys
 from pathlib import Path
+from typing import Optional
 
 from loguru import logger as log
 
-from .run_state import get_run, list_runs
+from .run_state import list_runs, prune_runs, read_status, watch_status
 
 app = typer.Typer(help="/ask status - Show learning progress")
 
@@ -232,44 +233,77 @@ def show_status(scope: str = "ask", as_json: bool = False):
 def main(
     scope: str = typer.Option(os.environ.get("ASK_DEFAULT_SCOPE", "ask"), help="Memory scope to check (default: ask)"),
     as_json: bool = typer.Option(False, "--json", help="JSON output"),
-    runs: bool = typer.Option(False, "--runs", help="Show recent /ask runtime runs"),
-    last: int = typer.Option(10, "--last", help="Number of recent runtime runs"),
-    run_id: str | None = typer.Option(None, "--id", help="Show one runtime run by id"),
+    run: Optional[str] = typer.Option(None, "--run", help="Show runtime status for an ask id, status file, or run directory"),
+    tail_events: int = typer.Option(0, "--tail-events", help="Include the last N runtime events"),
+    watch: bool = typer.Option(False, "--watch", help="Watch runtime status until the run reaches a terminal state"),
+    watch_timeout_seconds: float = typer.Option(300, "--watch-timeout-seconds", help="Maximum seconds to wait with --watch"),
+    poll_interval_seconds: float = typer.Option(1, "--poll-interval-seconds", help="Polling interval for --watch"),
+    runs: bool = typer.Option(False, "--runs", help="List recent runtime runs"),
+    limit: int = typer.Option(20, "--limit", help="Maximum runs to list with --runs"),
+    prune: bool = typer.Option(False, "--prune", help="Prune old runtime run directories"),
+    older_than_days: int = typer.Option(14, "--older-than-days", help="Age threshold for --prune"),
+    dry_run: bool = typer.Option(False, "--dry-run", help="Preview --prune without deleting"),
+    run_output_root: Optional[str] = typer.Option(None, "--run-output-root", help="Runtime artifact root for --run ids"),
     debug: bool = typer.Option(False, help="Enable debug logging"),
 ):
     if debug:
         log.enable("")
 
-    if runs or run_id:
-        if run_id:
-            payload = get_run(run_id) or {"status": None, "request": None, "error": "run not found"}
-        else:
-            payload = {"runs": list_runs(last=last)}
+    if prune:
+        payload = prune_runs(output_root=run_output_root, older_than_days=older_than_days, dry_run=dry_run)
         if as_json:
-            print(json.dumps(payload, indent=2, sort_keys=True))
+            print(json.dumps(payload, indent=2, default=str))
             return
-        if run_id:
-            status = payload.get("status") or {}
-            if not status:
-                print(f"/ask run not found: {run_id}")
-                return
-            print(f"/ask run {status.get('run_id')}: {status.get('state')}")
-            print(f"  mode: {status.get('mode')}")
-            print(f"  artifact_dir: {status.get('artifact_dir')}")
-            print(f"  verifier_status: {status.get('verifier_status', '')}")
-            print(f"  final_verdict: {status.get('final_verdict', '')}")
-            print(f"  needs_attention: {status.get('needs_attention', '')}")
+        action = "Would remove" if dry_run else "Removed"
+        print(f"/ask runs prune: {action} {len(payload['removed'])} run(s)")
+        for path in payload["removed"]:
+            print(f"  {path}")
+        return
+
+    if runs:
+        payload = {"runs": list_runs(output_root=run_output_root, limit=limit)}
+        if as_json:
+            print(json.dumps(payload, indent=2, default=str))
             return
-        print("/ask recent runs:")
-        for status in payload["runs"]:
+        print("/ask runs:")
+        for run_payload in payload["runs"]:
             print(
-                f"- {status.get('run_id')} "
-                f"[{status.get('mode')}] {status.get('state')} "
-                f"verdict={status.get('final_verdict', '')} "
-                f"attention={status.get('needs_attention', '')}"
+                f"  {run_payload.get('ask_id', 'unknown')} "
+                f"{run_payload.get('state', 'unknown')} "
+                f"{run_payload.get('updated_at', '')}"
             )
         return
 
+    if run:
+        if watch:
+            try:
+                watch_status(
+                    run,
+                    interval=poll_interval_seconds,
+                    tail_events=max(tail_events, 1),
+                    timeout_seconds=watch_timeout_seconds,
+                    output_root=run_output_root,
+                )
+            except TimeoutError as exc:
+                typer.echo(f"Error: {exc}", err=True)
+                raise typer.Exit(code=2)
+            return
+        payload = read_status(run, tail_events=tail_events, output_root=run_output_root)
+        if as_json:
+            print(json.dumps(payload, indent=2, default=str))
+            return
+        print(f"/ask run status: {payload.get('ask_id', run)}")
+        print(f"  State: {payload.get('state', 'unknown')}")
+        print(f"  Updated: {payload.get('updated_at', '')}")
+        artifacts = payload.get("artifacts", {})
+        if artifacts:
+            print("  Artifacts:")
+            for name, path in artifacts.items():
+                print(f"    {name}: {path}")
+        for event in payload.get("event_tail", []):
+            print(f"  Event: {event.get('event', 'unknown')} {event.get('ts', '')}")
+        return
+
     show_status(scope=scope, as_json=as_json)
 
 
diff --git a/skills/ask/tests/test_run_state_protocol.py b/skills/ask/tests/test_run_state_protocol.py
new file mode 100644
index 00000000..c723b31b
--- /dev/null
+++ b/skills/ask/tests/test_run_state_protocol.py
@@ -0,0 +1,580 @@
+"""Runtime artifact protocol tests for ask."""
+
+import json
+import os
+import time
+
+import pytest
+from typer.testing import CliRunner
+
+import ask.ask as ask_module
+import ask.nightly as nightly_module
+import ask.os_learn as os_learn_module
+import ask.os_query as os_query_module
+import ask.pipeline as pipeline_module
+import ask.status as status_module
+from ask.doctor import run_doctor
+from ask.runtime_schema import validate_run_dir, validate_runtime_tree
+from ask.run_state import AskRunState, make_run_id, list_runs, prune_runs, read_status, watch_status
+
+
+def test_run_state_writes_request_status_and_events(tmp_path):
+    run = AskRunState("protocol-test", output_root=tmp_path)
+    run.write_request({"question": "what changed?", "scope": "ask"})
+    run.event("custom_event", detail="ok")
+    run.finish({"question": "what changed?", "scope": "ask", "items": [{"solution": "ok"}]})
+
+    assert run.request_path.exists()
+    assert run.status_path.exists()
+    assert run.events_path.exists()
+
+    request = json.loads(run.request_path.read_text())
+    status = json.loads(run.status_path.read_text())
+    events = [json.loads(line) for line in run.events_path.read_text().splitlines()]
+
+    assert request["runtime_protocol_version"] == "ask.runtime.v1"
+    assert status["state"] == "answered"
+    assert status["artifacts"]["request"] == str(run.request_path)
+    assert [event["event"] for event in events] == ["request_written", "custom_event", "finished"]
+    assert validate_run_dir(run.run_dir)["ok"]
+
+
+def test_runtime_tree_schema_validation_reports_invalid_runs(tmp_path):
+    valid = AskRunState("schema-valid", output_root=tmp_path)
+    valid.write_request({"question": "schema"})
+    valid.finish({"question": "schema", "items": []})
+    invalid = tmp_path / "schema-invalid"
+    invalid.mkdir()
+    (invalid / "schema-invalid.status.json").write_text("{}")
+
+    result = validate_runtime_tree(tmp_path)
+
+    assert not result["ok"]
+    assert result["runs_checked"] == 2
+    assert any(item["run_dir"].endswith("schema-invalid") for item in result["invalid_runs"])
+
+
+def test_read_status_includes_event_tail(tmp_path):
+    run = AskRunState("tail-test", output_root=tmp_path)
+    run.write_request({"question": "tail?", "scope": "ask"})
+    run.event("middle")
+    run.finish({"question": "tail?", "scope": "ask", "items": []})
+
+    status = read_status("tail-test", tail_events=2, output_root=tmp_path)
+
+    assert status["state"] == "no_results"
+    assert [event["event"] for event in status["event_tail"]] == ["middle", "finished"]
+
+
+def test_run_state_needs_attention_and_artifact_registration_survive_finish(tmp_path):
+    run = AskRunState("attention-test", output_root=tmp_path)
+    run.write_request({"question": "safe to proceed?", "scope": "ask"})
+    attention = run.needs_attention(
+        reason="missing_deep_review_target",
+        question="Deep review needs an explicit target.",
+        resume_hint="Run again with --deep-review-target <target>.",
+    )
+    run.add_artifacts({"review_md": tmp_path / "review.md", "review_json": tmp_path / "review.json"})
+    run.finish({"question": "safe to proceed?", "items": []}, state="needs_attention")
+
+    status = read_status("attention-test", tail_events=10, output_root=tmp_path)
+
+    assert attention["reason"] == "missing_deep_review_target"
+    assert status["state"] == "needs_attention"
+    assert status["artifacts"]["review_md"].endswith("review.md")
+    assert status["needs_attention"]["resume_hint"] == "Run again with --deep-review-target <target>."
+
+
+def test_cli_ask_writes_runtime_artifacts(monkeypatch, tmp_path):
+    captured = {}
+
+    def fake_ask(**kwargs):
+        captured.update(kwargs)
+        return {"question": kwargs["question"], "scope": kwargs["scope"], "items": [{"solution": "ok"}]}
+
+    monkeypatch.setattr(ask_module, "ask", fake_ask)
+    result = CliRunner().invoke(
+        ask_module.app,
+        [
+            "what",
+            "changed?",
+            "--ask-id",
+            "cli-protocol",
+            "--run-output-root",
+            str(tmp_path),
+        ],
+    )
+
+    assert result.exit_code == 0
+    status = read_status("cli-protocol", tail_events=10, output_root=tmp_path)
+    request = json.loads((tmp_path / "cli-protocol" / "cli-protocol.request.json").read_text())
+
+    assert captured["question"] == "what changed?"
+    assert request["question"] == "what changed?"
+    assert status["state"] == "answered"
+    assert [event["event"] for event in status["event_tail"]] == ["request_written", "ask_started", "finished"]
+
+
+def test_cli_deep_review_missing_target_pauses_with_needs_attention(tmp_path):
+    result = CliRunner().invoke(
+        ask_module.app,
+        [
+            "safe",
+            "to",
+            "proceed?",
+            "--ask-id",
+            "missing-target",
+            "--run-output-root",
+            str(tmp_path),
+            "--json",
+        ],
+    )
+
+    assert result.exit_code == 2
+    status = read_status("missing-target", tail_events=10, output_root=tmp_path)
+    assert status["state"] == "needs_attention"
+    assert status["needs_attention"]["reason"] == "missing_deep_review_target"
+    assert status["needs_attention"]["safe_default"] == "do_not_run_review"
+    assert any(event["event"] == "needs_attention" for event in status["event_tail"])
+    payload = json.loads(result.stdout)
+    assert payload["needs_attention"]["safe_default"] == "do_not_run_review"
+
+
+def test_doctor_reports_runtime_sections():
+    result = run_doctor()
+
+    assert result["status"] in {"pass", "fail"}
+    assert result["run_root"]
+    assert any(check["name"] == "artifact_root_writable" for check in result["checks"])
+    assert any(check["name"] == "runtime_artifact_schema" for check in result["checks"])
+    assert any(check["name"] == "skill:memory" for check in result["checks"])
+
+
+def test_list_runs_returns_recent_statuses(tmp_path):
+    older = AskRunState("older", output_root=tmp_path)
+    older.write_request({"question": "older"})
+    older.finish({"question": "older", "items": []})
+    newer = AskRunState("newer", output_root=tmp_path)
+    newer.write_request({"question": "newer"})
+    newer.finish({"question": "newer", "items": [{"solution": "ok"}]})
+
+    runs = list_runs(output_root=tmp_path, limit=2)
+
+    assert {run["ask_id"] for run in runs} == {"older", "newer"}
+    assert all("_status_path" in run for run in runs)
+
+
+def test_runtime_index_is_append_only_and_powers_runs_listing(tmp_path):
+    run = AskRunState("indexed", output_root=tmp_path)
+    run.write_request({"command": "ask", "question": "indexed"})
+    run.finish({"question": "indexed", "items": [{"solution": "ok"}]})
+
+    index_path = tmp_path / "index.jsonl"
+    runs = list_runs(output_root=tmp_path, limit=1)
+
+    assert index_path.exists()
+    assert len(index_path.read_text().splitlines()) >= 2
+    assert runs[0]["ask_id"] == "indexed"
+
+
+def test_prune_runs_removes_old_run_dirs(tmp_path):
+    old = AskRunState("old-run", output_root=tmp_path)
+    old.write_request({"question": "old"})
+    old.finish({"question": "old", "items": []})
+    new = AskRunState("new-run", output_root=tmp_path)
+    new.write_request({"question": "new"})
+    new.finish({"question": "new", "items": []})
+    old_time = time.time() - 30 * 24 * 60 * 60
+    os.utime(old.run_dir, (old_time, old_time))
+
+    preview = prune_runs(output_root=tmp_path, older_than_days=14, dry_run=True)
+    result = prune_runs(output_root=tmp_path, older_than_days=14)
+
+    assert str(old.run_dir) in preview["removed"]
+    assert str(old.run_dir) in result["removed"]
+    assert not old.run_dir.exists()
+    assert new.run_dir.exists()
+
+
+def test_prune_runs_keeps_unrecognized_old_dirs(tmp_path):
+    unrelated = tmp_path / "unrelated-old-dir"
+    unrelated.mkdir()
+    old_time = time.time() - 30 * 24 * 60 * 60
+    os.utime(unrelated, (old_time, old_time))
+
+    result = prune_runs(output_root=tmp_path, older_than_days=14)
+
+    assert unrelated.exists()
+    assert str(unrelated) not in result["removed"]
+    assert str(unrelated) in result["kept"]
+
+
+def test_prune_runs_keeps_malformed_and_mismatched_status_dirs(tmp_path):
+    malformed = tmp_path / "malformed"
+    malformed.mkdir()
+    (malformed / "malformed.status.json").write_text("{not-json")
+    mismatch = tmp_path / "mismatch"
+    mismatch.mkdir()
+    (mismatch / "mismatch.status.json").write_text(json.dumps({
+        "runtime_protocol_version": "ask.runtime.v1",
+        "ask_id": "other",
+        "artifacts": {"run_dir": str(mismatch)},
+    }))
+    old_time = time.time() - 30 * 24 * 60 * 60
+    os.utime(malformed, (old_time, old_time))
+    os.utime(mismatch, (old_time, old_time))
+
+    result = prune_runs(output_root=tmp_path, older_than_days=14)
+
+    assert malformed.exists()
+    assert mismatch.exists()
+    assert str(malformed) in result["kept"]
+    assert str(mismatch) in result["kept"]
+
+
+def test_prune_runs_keeps_symlinked_dirs(tmp_path):
+    target = tmp_path / "target"
+    target.mkdir()
+    symlink = tmp_path / "linked"
+    symlink.symlink_to(target, target_is_directory=True)
+    old_time = time.time() - 30 * 24 * 60 * 60
+    os.utime(symlink, (old_time, old_time), follow_symlinks=False)
+
+    result = prune_runs(output_root=tmp_path, older_than_days=14)
+
+    assert symlink.exists()
+    assert target.exists()
+    assert str(symlink) not in result["removed"]
+
+
+def test_cli_status_prune_dry_run_lists_old_run_dirs(tmp_path):
+    old = AskRunState("old-cli-run", output_root=tmp_path)
+    old.write_request({"question": "old"})
+    old.finish({"question": "old", "items": []})
+    old_time = time.time() - 30 * 24 * 60 * 60
+    os.utime(old.run_dir, (old_time, old_time))
+
+    result = CliRunner().invoke(
+        status_module.app,
+        ["--prune", "--older-than-days", "14", "--dry-run", "--run-output-root", str(tmp_path), "--json"],
+    )
+
+    assert result.exit_code == 0
+    payload = json.loads(result.stdout)
+    assert str(old.run_dir) in payload["removed"]
+    assert old.run_dir.exists()
+
+
+def test_reused_ask_id_is_rejected_by_default(tmp_path):
+    first = AskRunState("same-id", output_root=tmp_path)
+    first.write_request({"question": "one"})
+    first.finish({"question": "one", "items": [{"solution": "ok"}]})
+
+    with pytest.raises(FileExistsError):
+        AskRunState("same-id", output_root=tmp_path)
+
+
+def test_overwrite_replaces_existing_run_dir(tmp_path):
+    first = AskRunState("same-id", output_root=tmp_path)
+    first.write_request({"question": "one"})
+    first.finish({"question": "one", "items": [{"solution": "ok"}]})
+
+    second = AskRunState("same-id", output_root=tmp_path, overwrite=True)
+    second.write_request({"question": "two"})
+
+    request = json.loads(second.request_path.read_text())
+    assert request["question"] == "two"
+
+
+def test_resume_rejects_terminal_state(tmp_path):
+    first = AskRunState("done-id", output_root=tmp_path)
+    first.write_request({"question": "done"})
+    first.finish({"question": "done", "items": [{"solution": "ok"}]})
+
+    with pytest.raises(FileExistsError):
+        AskRunState("done-id", output_root=tmp_path, resume=True)
+
+
+def test_resume_accepts_running_state(tmp_path):
+    first = AskRunState("running-id", output_root=tmp_path)
+    first.write_request({"question": "running"})
+    first.update("running", current_step="memory_recall")
+
+    resumed = AskRunState("running-id", output_root=tmp_path, resume=True)
+
+    assert resumed.ask_id == "running-id"
+
+
+def test_make_run_id_same_question_does_not_collide():
+    assert make_run_id("same question") != make_run_id("same question")
+
+
+def test_watch_status_times_out_for_nonterminal_run(tmp_path):
+    run = AskRunState("stuck", output_root=tmp_path)
+    run.write_request({"question": "stuck"})
+    run.update("running", current_step="memory_recall")
+
+    with pytest.raises(TimeoutError):
+        watch_status("stuck", output_root=tmp_path, interval=0.01, timeout_seconds=0.05)
+
+
+def test_cli_status_watch_timeout_exits_nonzero(tmp_path):
+    run = AskRunState("stuck-cli", output_root=tmp_path)
+    run.write_request({"question": "stuck"})
+    run.update("running", current_step="memory_recall")
+
+    result = CliRunner().invoke(
+        status_module.app,
+        [
+            "--run",
+            "stuck-cli",
+            "--watch",
+            "--watch-timeout-seconds",
+            "0.05",
+            "--poll-interval-seconds",
+            "0.01",
+            "--run-output-root",
+            str(tmp_path),
+        ],
+    )
+
+    assert result.exit_code == 2
+    assert "Timed out watching" in result.stderr
+
+
+def test_artifact_write_failure_degrades_plain_ask(monkeypatch):
+    def broken_run_state(*args, **kwargs):
+        raise OSError("read-only artifact root")
+
+    def fake_ask(**kwargs):
+        return {"question": kwargs["question"], "scope": kwargs["scope"], "items": [{"solution": "ok"}]}
+
+    monkeypatch.setattr(ask_module, "AskRunState", broken_run_state)
+    monkeypatch.setattr(ask_module, "ask", fake_ask)
+
+    result = CliRunner().invoke(ask_module.app, ["what", "changed?"])
+
+    assert result.exit_code == 0
+    assert "Runtime artifacts disabled" in result.stderr
+
+
+def test_artifact_write_failure_fails_closed_for_deep_review(monkeypatch):
+    def broken_run_state(*args, **kwargs):
+        raise OSError("read-only artifact root")
+
+    monkeypatch.setattr(ask_module, "AskRunState", broken_run_state)
+
+    result = CliRunner().invoke(ask_module.app, ["safe", "to", "proceed?", "--deep-review"])
+
+    assert result.exit_code != 0
+    assert "Runtime artifacts disabled" not in result.stderr
+
+
+def test_cli_ask_dry_run_emits_spec_without_artifacts(tmp_path):
+    result = CliRunner().invoke(
+        ask_module.app,
+        [
+            "safe",
+            "to",
+            "proceed?",
+            "--deep-review",
+            "--dry-run",
+            "--ask-id",
+            "dry-ask",
+            "--run-output-root",
+            str(tmp_path),
+            "--json",
+        ],
+    )
+
+    assert result.exit_code == 0
+    payload = json.loads(result.stdout)
+    assert payload["spec_protocol_version"] == "ask.dry_run.v1"
+    assert payload["options"]["deep_review"] is True
+    assert not (tmp_path / "dry-ask").exists()
+
+
+def test_cli_ask_chain_and_reviewer_specs_feed_dry_run_options(tmp_path):
+    result = CliRunner().invoke(
+        ask_module.app,
+        [
+            "review",
+            "runtime",
+            "--chain",
+            "deep-review-safety",
+            "--reviewer-spec",
+            "security",
+            "--dry-run",
+            "--run-output-root",
+            str(tmp_path),
+            "--json",
+        ],
+    )
+
+    assert result.exit_code == 0
+    payload = json.loads(result.stdout)
+    options = payload["options"]
+    assert options["deep_review"] is True
+    assert options["parallel_review"] is True
+    assert "secret-persistence" in options["deep_review_focus"]
+
+
+def test_cli_real_non_oracle_ask_smoke_writes_granular_events(monkeypatch, tmp_path):
+    def fake_recall(question, scope, k):
+        return {
+            "returncode": 0,
+            "stdout": json.dumps({"items": [{"problem": question, "solution": "Runtime protocol exists."}]}),
+            "stderr": "",
+        }
+
+    monkeypatch.setattr(ask_module, "run_memory_recall", fake_recall)
+    monkeypatch.setattr(ask_module, "_has_relevant_domain_items", lambda items, question: True)
+    monkeypatch.setattr(ask_module.SessionWriter, "write", lambda self: None)
+    monkeypatch.setattr(ask_module, "_record_ask_telemetry", lambda **kwargs: None)
+
+    result = CliRunner().invoke(
+        ask_module.app,
+        [
+            "what",
+            "changed?",
+            "--raw",
+            "--ask-id",
+            "real-smoke",
+            "--run-output-root",
+            str(tmp_path),
+        ],
+    )
+
+    assert result.exit_code == 0
+    status = read_status("real-smoke", tail_events=20, output_root=tmp_path)
+    events = [event["event"] for event in status["event_tail"]]
+    assert "memory_recall_started" in events
+    assert "memory_recall_finished" in events
+    assert "synthesis_started" in events
+    assert "synthesis_finished" in events
+    assert status["state"] == "answered"
+
+
+def test_cli_learn_writes_runtime_artifacts(monkeypatch, tmp_path):
+    captured = {}
+
+    def fake_learn(**kwargs):
+        captured.update(kwargs)
+        return {"topic": kwargs["topic"], "stored": 0, "memory_existing": 1, "items": []}
+
+    monkeypatch.setattr(pipeline_module, "learn", fake_learn)
+    result = CliRunner().invoke(
+        pipeline_module.app,
+        ["topic", "--ask-id", "learn-smoke", "--run-output-root", str(tmp_path)],
+    )
+
+    assert result.exit_code == 0
+    assert captured["run_state"].ask_id == "learn-smoke"
+    assert read_status("learn-smoke", output_root=tmp_path)["state"] == "completed"
+
+
+def test_cli_learn_dry_run_emits_spec_without_artifacts(tmp_path):
+    result = CliRunner().invoke(
+        pipeline_module.app,
+        ["topic", "--dry-run", "--ask-id", "learn-dry", "--run-output-root", str(tmp_path)],
+    )
+
+    assert result.exit_code == 0
+    payload = json.loads(result.stdout)
+    assert payload["command"] == "learn"
+    assert not (tmp_path / "learn-dry").exists()
+
+
+def test_cli_nightly_writes_runtime_artifacts(monkeypatch, tmp_path):
+    def fake_nightly_update(**kwargs):
+        return {
+            "scope": kwargs["scope"],
+            "personas_checked": 0,
+            "personas_updated": 1,
+            "items_stored": 1,
+            "errors": [],
+        }
+
+    monkeypatch.setattr(nightly_module, "nightly_update", fake_nightly_update)
+    result = CliRunner().invoke(
+        nightly_module.app,
+        ["--ask-id", "nightly-smoke", "--run-output-root", str(tmp_path)],
+    )
+
+    assert result.exit_code == 0
+    assert read_status("nightly-smoke", output_root=tmp_path)["state"] == "completed"
+
+
+def test_cli_nightly_dry_run_emits_spec_without_artifacts(tmp_path):
+    result = CliRunner().invoke(
+        nightly_module.app,
+        ["--dry-run", "--ask-id", "nightly-dry", "--run-output-root", str(tmp_path), "--json"],
+    )
+
+    assert result.exit_code == 0
+    payload = json.loads(result.stdout)
+    assert payload["command"] == "nightly"
+    assert not (tmp_path / "nightly-dry").exists()
+
+
+def test_cli_os_learn_writes_runtime_artifacts(monkeypatch, tmp_path):
+    monkeypatch.setattr(
+        os_learn_module,
+        "learn_os",
+        lambda **kwargs: {"stored": 1, "dry_run": False, "items": [], "errors": 0},
+    )
+    result = CliRunner().invoke(
+        os_learn_module.app,
+        ["--ask-id", "os-learn-smoke", "--run-output-root", str(tmp_path)],
+    )
+
+    assert result.exit_code == 0
+    assert read_status("os-learn-smoke", output_root=tmp_path)["state"] == "completed"
+
+
+def test_cli_os_learn_dry_run_emits_spec_without_artifacts(tmp_path):
+    result = CliRunner().invoke(
+        os_learn_module.app,
+        ["--dry-run", "--ask-id", "os-learn-dry", "--run-output-root", str(tmp_path), "--json"],
+    )
+
+    assert result.exit_code == 0
+    payload = json.loads(result.stdout)
+    assert payload["command"] == "os learn"
+    assert not (tmp_path / "os-learn-dry").exists()
+
+
+def test_cli_os_ask_writes_runtime_artifacts(monkeypatch, tmp_path):
+    monkeypatch.setattr(
+        os_query_module,
+        "recall_os",
+        lambda question, k=5, tags=None, timeout=15: [{"problem": question, "solution": "memory skill"}],
+    )
+    result = CliRunner().invoke(
+        os_query_module.app,
+        ["ask", "which skills provide memory?", "--ask-id", "os-ask-smoke", "--run-output-root", str(tmp_path)],
+    )
+
+    assert result.exit_code == 0
+    assert read_status("os-ask-smoke", output_root=tmp_path)["state"] == "answered"
+
+
+def test_cli_os_health_writes_runtime_artifacts(monkeypatch, tmp_path):
+    monkeypatch.setattr(os_query_module, "get_health_data", lambda subsystem: {"status": "ok"})
+    monkeypatch.setattr(os_query_module, "recall_os", lambda *args, **kwargs: [])
+    result = CliRunner().invoke(
+        os_query_module.app,
+        [
+            "health",
+            "is memory healthy?",
+            "--subsystem",
+            "memory",
+            "--ask-id",
+            "os-health-smoke",
+            "--run-output-root",
+            str(tmp_path),
+        ],
+    )
+
+    assert result.exit_code == 0
+    assert read_status("os-health-smoke", output_root=tmp_path)["state"] == "completed"
diff --git a/skills/review-code/SKILL.md b/skills/review-code/SKILL.md
index 2a1af005..ed680a3c 100644
--- a/skills/review-code/SKILL.md
+++ b/skills/review-code/SKILL.md
@@ -105,6 +105,7 @@ Use the table below to map user requests to the correct command.
 | "Quick one-shot via subagent"     | Read files, `POST /chat` to `/subagent-service` with inline content (see above)    |
 | "Quick review via scillm/Codex"   | `one-shot -f file1.ts -f file2.py --context "..." --persona senior --model gpt-5.3-codex` |
 | "Review with Gemini via scillm"   | `one-shot -f file1.ts --context "..." --persona nico --model text-gemini --focus "security"` |
+| "Bundle for Web GPT review"       | `bundle --context "What changed and why" -R src/file.py -R tests/test_file.py`                 |
 
 > **💡 COST-SAVING TIP**: Always use `--provider github` for Claude models to avoid API charges. The `github` provider includes Claude models at no additional cost beyond your GitHub Copilot subscription.
 
@@ -169,12 +170,86 @@ code_review.py loop \
 
 ### bundle
 
-Bundle request for copy/paste into GitHub Copilot web (if CLI is unavailable).
+Bundle a complete markdown review request for Web GPT or another external reviewer.
+The command writes a markdown file to `/tmp/review-code-request-*.md` by default and copies
+the same content to the clipboard with `xclip` when available.
+
+Default bundle behavior is intentionally selective. It does not dump every changed
+file just because the worktree is dirty. Select the review surface with
+`--review-file` / `-R`; use `--all-changed` only when a broad repository diff is
+the actual review target.
+
+The bundle includes:
+
+- reviewer instructions
+- explicit decision requested, when supplied
+- supplied rationale/context
+- expected contract/invariants, when supplied
+- prior critique to re-check, when supplied
+- review non-goals, when supplied
+- optional existing request file
+- repo branch, remote, and scoped status
+- selected review files and changed files in that selected scope
+- scoped git diff for selected files
+- optional selected file contents, capped per file
+- strict merge-gate output format, unless disabled
 
 ```bash
-code_review.py bundle --file request.md --clipboard
+# Bundle selected files and copy to clipboard with xclip
+code_review.py bundle \
+  --context "Runtime status protocol changes for code-runner" \
+  -R src/runtime.py \
+  -R tests/test_runtime.py
+
+# State the safety contract instead of making the reviewer infer intent
+code_review.py bundle \
+  --title "Targeted Review: /ask Runtime Safety" \
+  --decision "Is the /ask runtime artifact layer safe enough to merge?" \
+  --context "Portable runtime observability for request/status/events artifacts" \
+  --expected-contract "Plain ask degrades if artifacts are unwritable" \
+  --expected-contract "Deep review fails closed if runtime artifacts cannot be written" \
+  --expected-contract "Run IDs are one-run-one-directory; reuse is rejected by default" \
+  --prior-critique "prune_runs may delete unrelated directories" \
+  --prior-critique "status --watch may hang forever" \
+  --non-goal "Do not review generated .ask_artifacts" \
+  -R skills/ask/src/ask/run_state.py \
+  -R skills/ask/src/ask/status.py \
+  -R skills/ask/src/ask/ask.py
+
+# Include an existing review request file
+code_review.py bundle --file request.md --context "Validate this implementation plan" -R src/runtime.py
+
+# Write to a specific markdown file and skip clipboard
+code_review.py bundle --output /tmp/review.md --no-clipboard
+
+# Broad scope is opt-in
+code_review.py bundle --all-changed --file-contents --context "Review the full worktree diff"
 ```
 
+Useful options:
+
+| Option | Description |
+|--------|-------------|
+| `--context` | Inline rationale/context to include |
+| `--context-file` | Markdown/text context file to include |
+| `--decision` | Specific merge/review decision the reviewer should answer |
+| `--expected-contract` | Expected invariant or behavior; repeat for multiple invariants |
+| `--expected-contract-file` | File containing expected invariants/contracts |
+| `--prior-critique` | Prior finding/risk to re-check; repeat for multiple items |
+| `--prior-critique-file` | File containing prior critique to re-check |
+| `--non-goal` | Topic the reviewer should explicitly avoid; repeat for multiple items |
+| `--non-goals-file` | File containing review non-goals |
+| `--no-required-output-format` | Omit the strict merge-gate output schema |
+| `--repo-dir` | Repository to inspect instead of current directory |
+| `--review-file`, `-R` | Specific file in the review scope; repeat for multiple files |
+| `--all-changed` | Explicitly include every changed file instead of selected files |
+| `--output` | Explicit markdown output path |
+| `--output-dir` | Directory for default generated bundle path |
+| `--no-clipboard` | Write the file without copying to `xclip` |
+| `--require-clipboard` | Fail if `xclip` is missing or copy fails |
+| `--no-diff` | Omit git diff |
+| `--file-contents` | Include selected changed file contents |
+
 ### find
 
 Find past review requests.
diff --git a/skills/review-code/commands/bundle.py b/skills/review-code/commands/bundle.py
index b9dc5c72..62f6e67e 100644
--- a/skills/review-code/commands/bundle.py
+++ b/skills/review-code/commands/bundle.py
@@ -1,10 +1,10 @@
-"""Bundle and find commands for code-review skill."""
+"""Bundle command for code-review skill."""
 from __future__ import annotations
 
-import json
+import os
 import shutil
 import subprocess
-from datetime import datetime
+from datetime import datetime, timezone
 from pathlib import Path
 from typing import Optional
 
@@ -17,191 +17,459 @@ except ImportError:
     from utils import check_git_status
 
 
-def bundle(
-    file: Path = typer.Option(..., "--file", "-f", help="Markdown request file"),
-    repo_dir: Optional[Path] = typer.Option(None, "--repo-dir", "-d", help="Repository directory to check git status"),
-    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file (default: stdout)"),
-    skip_git_check: bool = typer.Option(False, "--skip-git-check", help="Skip git status verification"),
-    clipboard: bool = typer.Option(False, "--clipboard", "-c", help="Copy to clipboard (requires xclip/pbcopy)"),
-) -> None:
-    """Bundle request for copy/paste into GitHub Copilot web.
+DEFAULT_MAX_DIFF_CHARS = 120_000
+DEFAULT_MAX_FILE_CHARS = 30_000
 
-    IMPORTANT: GitHub Copilot web can only see changes that are:
-    1. Committed to git
-    2. Pushed to a remote feature branch
 
-    This command checks git status and warns if changes aren't pushed.
+def _run_command(args: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
+    return subprocess.run(args, cwd=cwd, capture_output=True, text=True, timeout=30)
 
-    Examples:
-        # Bundle and check git status
-        code_review.py bundle --file request.md --repo-dir /path/to/repo
 
-        # Bundle to file
-        code_review.py bundle --file request.md --output copilot_request.txt
+def _git_output(args: list[str], cwd: Path) -> str:
+    try:
+        result = _run_command(["git", *args], cwd)
+    except Exception:
+        return ""
+    if result.returncode != 0:
+        return ""
+    return result.stdout.strip()
 
-        # Bundle to clipboard
-        code_review.py bundle --file request.md --clipboard
 
-        # Skip git check (if you know it's pushed)
-        code_review.py bundle --file request.md --skip-git-check
-    """
-    if not file.exists():
-        typer.echo(f"Error: File not found: {file}", err=True)
+def _resolve_repo_dir(repo_dir: Optional[Path]) -> Path:
+    start = (repo_dir or Path.cwd()).resolve()
+    root = _git_output(["rev-parse", "--show-toplevel"], start)
+    return Path(root).resolve() if root else start
+
+
+def _git_path_args(paths: list[str]) -> list[str]:
+    return ["--", *paths] if paths else []
+
+
+def _collect_changed_files(repo_dir: Path, paths: list[str]) -> list[str]:
+    path_args = _git_path_args(paths)
+    tracked = _git_output(["diff", "--name-only", "HEAD", *path_args], repo_dir).splitlines()
+    untracked = _git_output(["ls-files", "--others", "--exclude-standard", *path_args], repo_dir).splitlines()
+    return sorted({path for path in [*tracked, *untracked] if path})
+
+
+def _git_status(repo_dir: Path, paths: list[str]) -> str:
+    return _git_output(["status", "--short", *_git_path_args(paths)], repo_dir) or "(clean)"
+
+
+def _collect_git_metadata(repo_dir: Path, paths: list[str], all_changed: bool) -> dict[str, str | list[str]]:
+    include_worktree_scope = all_changed or bool(paths)
+    status = _git_status(repo_dir, paths) if include_worktree_scope else (
+        "(omitted: pass --review-file for selected files or --all-changed to include every changed file)"
+    )
+    changed_files = _collect_changed_files(repo_dir, paths) if include_worktree_scope else []
+    return {
+        "root": str(repo_dir),
+        "branch": _git_output(["branch", "--show-current"], repo_dir) or "(unknown)",
+        "remote": _git_output(["remote", "get-url", "origin"], repo_dir) or "(none)",
+        "status": status,
+        "changed_files": changed_files,
+    }
+
+
+def _truncate(text: str, max_chars: int) -> str:
+    if max_chars <= 0 or len(text) <= max_chars:
+        return text
+    omitted = len(text) - max_chars
+    return f"{text[:max_chars]}\n\n[truncated: omitted {omitted} characters]\n"
+
+
+def _selected_diff(repo_dir: Path, paths: list[str], all_changed: bool) -> str:
+    diff_paths = [] if all_changed else paths
+    changed_files = _collect_changed_files(repo_dir, diff_paths)
+    tracked_diff = _git_output(["diff", "--binary", "HEAD", *_git_path_args(diff_paths)], repo_dir)
+    untracked = set(_git_output(["ls-files", "--others", "--exclude-standard", *_git_path_args(diff_paths)], repo_dir).splitlines())
+    untracked_diffs = []
+    for rel_path in changed_files:
+        if rel_path not in untracked:
+            continue
+        path = repo_dir / rel_path
+        if not path.is_file():
+            continue
+        result = subprocess.run(
+            ["git", "diff", "--no-index", "--", "/dev/null", rel_path],
+            cwd=repo_dir,
+            capture_output=True,
+            text=True,
+            timeout=30,
+        )
+        if result.returncode in {0, 1} and result.stdout:
+            untracked_diffs.append(result.stdout)
+    return "\n".join(part for part in [tracked_diff, *untracked_diffs] if part).strip()
+
+
+def _read_optional_file(path: Optional[Path], label: str) -> str:
+    if not path:
+        return ""
+    if not path.exists():
+        typer.echo(f"Error: {label} not found: {path}", err=True)
         raise typer.Exit(code=1)
+    return path.read_text(errors="replace").strip()
 
-    # Check git status if repo_dir provided
-    if repo_dir and not skip_git_check:
-        git_status = check_git_status(repo_dir)
 
-        typer.echo("--- Git Status Check ---", err=True)
-        typer.echo(f"Branch: {git_status['current_branch'] or 'unknown'}", err=True)
-        typer.echo(f"Remote: {git_status['remote_branch'] or 'not tracking'}", err=True)
+def _read_context(context: Optional[str], context_file: Optional[Path]) -> str:
+    parts = []
+    if context:
+        parts.append(context.strip())
+    file_content = _read_optional_file(context_file, "context file")
+    if file_content:
+        parts.append(file_content)
+    return "\n\n".join(parts).strip()
 
-        if git_status["has_uncommitted"]:
-            typer.echo("WARNING: Uncommitted changes detected!", err=True)
-            typer.echo("  -> Copilot web won't see these changes", err=True)
-            typer.echo("  -> Run: git add . && git commit -m 'message'", err=True)
 
-        if git_status["has_unpushed"]:
-            typer.echo("WARNING: Unpushed commits detected!", err=True)
-            typer.echo("  -> Copilot web won't see these changes", err=True)
-            typer.echo(f"  -> Run: git push origin {git_status['current_branch']}", err=True)
+def _read_list_section(values: Optional[list[str]], file: Optional[Path], label: str) -> str:
+    parts = [value.strip() for value in values or [] if value.strip()]
+    file_content = _read_optional_file(file, label)
+    if file_content:
+        parts.append(file_content)
+    return "\n\n".join(parts).strip()
 
-        if not git_status["has_uncommitted"] and not git_status["has_unpushed"]:
-            typer.echo("OK: All changes committed and pushed", err=True)
 
-        typer.echo("------------------------", err=True)
+def _normalize_review_files(repo_dir: Path, review_files: Optional[list[Path]]) -> list[str]:
+    if not review_files:
+        return []
+
+    normalized: list[str] = []
+    for review_file in review_files:
+        path = review_file.expanduser()
+        if not path.is_absolute():
+            path = repo_dir / path
+        try:
+            rel_path = path.resolve().relative_to(repo_dir)
+        except ValueError:
+            typer.echo(f"Error: review file is outside repo: {review_file}", err=True)
+            raise typer.Exit(code=1)
+        rel = rel_path.as_posix()
+        if rel not in normalized:
+            normalized.append(rel)
+    return normalized
+
+
+def _safe_changed_file_contents(repo_dir: Path, changed_files: list[str], max_file_chars: int) -> str:
+    sections = []
+    for rel_path in changed_files:
+        path = (repo_dir / rel_path).resolve()
+        try:
+            path.relative_to(repo_dir)
+        except ValueError:
+            continue
+        if not path.is_file():
+            continue
+        try:
+            content = path.read_text(errors="replace")
+        except Exception as exc:
+            sections.append(f"### `{rel_path}`\n\n[unable to read file: {exc}]\n")
+            continue
+        sections.append(
+            f"### `{rel_path}`\n\n"
+            f"```text\n{_truncate(content, max_file_chars)}\n```\n"
+        )
+    return "\n".join(sections) if sections else "(No changed file contents included.)"
+
+
+def _copy_to_clipboard(content: str, require_clipboard: bool) -> None:
+    tool = shutil.which("xclip")
+    if tool:
+        proc = subprocess.run(
+            [tool, "-selection", "clipboard"],
+            input=content,
+            text=True,
+            capture_output=True,
+        )
+        if proc.returncode == 0:
+            typer.echo("Copied bundle to clipboard with xclip", err=True)
+            return
+        message = proc.stderr.strip() or "xclip failed"
+        if require_clipboard:
+            typer.echo(f"Error: {message}", err=True)
+            raise typer.Exit(code=1)
+        typer.echo(f"Warning: clipboard copy failed: {message}", err=True)
+        return
+
+    if require_clipboard:
+        typer.echo("Error: xclip not found; install xclip or use --no-clipboard", err=True)
+        raise typer.Exit(code=1)
+    typer.echo("Warning: xclip not found; wrote markdown file but did not copy clipboard", err=True)
 
-    # Read and prepare the bundle
-    request_content = file.read_text()
 
-    # Add header for Copilot web
-    bundle_content = f"""=== CODE REVIEW REQUEST FOR GITHUB COPILOT WEB ===
+def _default_output_path(output_dir: Path) -> Path:
+    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
+    return output_dir / f"review-code-request-{stamp}.md"
 
-INSTRUCTIONS:
-1. Ensure your changes are committed and pushed to the feature branch
-2. Open GitHub Copilot web (copilot.github.com)
-3. Paste this entire content as your prompt
-4. Copilot will analyze the repo/branch and generate a patch
 
---- BEGIN REQUEST ---
+def _optional_section(title: str, content: str) -> str:
+    if not content:
+        return ""
+    return f"\n## {title}\n\n{content}\n"
 
-{request_content}
 
---- END REQUEST ---
+def _required_output_section(include: bool) -> str:
+    if not include:
+        return ""
+    return """
+## Required Output Format
+
+Return:
+
+# Merge-blocking findings
+
+## High severity
+
+### H1. <title>
+- Evidence:
+- Impact:
+- Exact fix:
+- Test that should fail before the fix:
+
+## Medium severity
+
+Only include if it should block merge or materially affect safety.
+
+# Important test gaps
+
+List only tests required before merge.
+
+# Merge recommendation
+
+Use exactly one:
+- SAFE_TO_MERGE
+- SAFE_WITH_CONDITIONS
+- CHANGES_REQUESTED
+- NOT_SAFE
 """
 
-    # Output
-    if clipboard:
-        try:
-            # Try xclip (Linux) or pbcopy (macOS)
-            if shutil.which("xclip"):
-                proc = subprocess.Popen(["xclip", "-selection", "clipboard"], stdin=subprocess.PIPE)
-                proc.communicate(bundle_content.encode())
-                typer.echo("Copied to clipboard (xclip)", err=True)
-            elif shutil.which("pbcopy"):
-                proc = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE)
-                proc.communicate(bundle_content.encode())
-                typer.echo("Copied to clipboard (pbcopy)", err=True)
-            else:
-                typer.echo("Error: No clipboard tool found (install xclip or pbcopy)", err=True)
-                print(bundle_content)
-        except Exception as e:
-            typer.echo(f"Clipboard error: {e}", err=True)
-            print(bundle_content)
-    elif output:
-        output.write_text(bundle_content)
-        typer.echo(f"Wrote bundle to {output}", err=True)
-    else:
-        print(bundle_content)
-
-
-def find(
-    pattern: str = typer.Option("*review*.md", "--pattern", "-p", help="Glob pattern for filenames"),
-    directory: Path = typer.Option(".", "--dir", "-d", help="Directory to search"),
-    recursive: bool = typer.Option(True, "--recursive/--no-recursive", "-r", help="Search recursively"),
-    limit: int = typer.Option(20, "--limit", "-l", help="Maximum results to show"),
-    sort_by: str = typer.Option("modified", "--sort", "-s", help="Sort by: modified, name, size"),
-    contains: Optional[str] = typer.Option(None, "--contains", "-c", help="Filter by content substring"),
-) -> None:
-    """Find review request markdown files.
 
-    Search for code review request files by pattern, with optional content filtering.
+def _build_review_bundle(
+    *,
+    title: str,
+    request_content: str,
+    repo_dir: Path,
+    git_metadata: dict[str, str | list[str]],
+    rationale: str,
+    decision: str,
+    expected_contract: str,
+    prior_critique: str,
+    non_goals: str,
+    include_required_output_format: bool,
+    include_diff: bool,
+    include_file_contents: bool,
+    selected_paths: list[str],
+    all_changed: bool,
+    max_diff_chars: int,
+    max_file_chars: int,
+) -> str:
+    changed_files = git_metadata["changed_files"]
+    assert isinstance(changed_files, list)
+    diff = ""
+    if include_diff:
+        if selected_paths or all_changed:
+            diff = _selected_diff(repo_dir, selected_paths, all_changed)
+            diff = _truncate(diff or "(No tracked-file diff available for selected files.)", max_diff_chars)
+        else:
+            diff = "(Diff omitted: pass --review-file for selected files or --all-changed to include every changed file.)"
+
+    file_contents = ""
+    if include_file_contents:
+        file_contents = _safe_changed_file_contents(repo_dir, changed_files, max_file_chars)
+
+    selected_paths_md = "\n".join(f"- `{path}`" for path in selected_paths) or "- (none selected)"
+    changed_files_md = "\n".join(f"- `{path}`" for path in changed_files) or "- (none detected in selected scope)"
+    generated_at = datetime.now(timezone.utc).isoformat()
+
+    return f"""# {title}
+
+## Reviewer Instructions
+
+Review this as a code review request for Web GPT or another external reviewer.
+Focus on correctness, regression risk, security, maintainability, test coverage, and mismatches between the stated intent and the actual diff.
+Do not rewrite the entire implementation unless the diff is fundamentally unsafe.
+Return findings first, grouped by severity, with concrete file/function references where possible.
+
+{_optional_section("Decision Needed", decision)}
+## Rationale And Context
+
+{rationale or "(No additional rationale/context supplied.)"}
+
+{_optional_section("Expected Safety Contract", expected_contract)}
+{_optional_section("Prior Critique Being Rechecked", prior_critique)}
+{_optional_section("Non-goals For This Review", non_goals)}
+
+## Original Review Request
+
+{request_content or "(No request file supplied; review the current repository changes.)"}
+
+## Repository Snapshot
+
+- Generated at: `{generated_at}`
+- Working directory: `{os.getcwd()}`
+- Repository root: `{git_metadata["root"]}`
+- Branch: `{git_metadata["branch"]}`
+- Remote: `{git_metadata["remote"]}`
+
+## Git Status
+
+```text
+{git_metadata["status"]}
+```
+
+## Selected Review Files
+
+These are the files intentionally selected for external review. Do not expand scope just because other files are changed in the worktree.
+
+{selected_paths_md if selected_paths else "(No selected files. This bundle includes request/context only unless --all-changed was used.)"}
+
+## Changed Files In Selected Scope
+
+{changed_files_md}
+
+## Diff
+
+```diff
+{diff if include_diff else "(Diff omitted by --no-diff.)"}
+```
+
+## Changed File Contents
+
+{file_contents if include_file_contents else "(File contents omitted by --no-file-contents.)"}
+
+## Review Questions
+
+1. Are there correctness bugs or edge cases in the implementation?
+2. Are there security, data-loss, concurrency, or rollback risks?
+3. Are the tests or validation steps sufficient for the stated change?
+4. Is the change scoped tightly, or does it introduce unrelated behavior?
+5. What exact fixes should be made before this is committed?
+{_required_output_section(include_required_output_format)}
+"""
+
+
+def bundle(
+    file: Optional[Path] = typer.Option(None, "--file", "-f", help="Optional existing markdown request file"),
+    repo_dir: Optional[Path] = typer.Option(None, "--repo-dir", "-d", help="Repository directory to check git status"),
+    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output markdown file (default: /tmp/review-code-request-*.md)"),
+    output_dir: Path = typer.Option(Path("/tmp"), "--output-dir", help="Directory for default bundle output"),
+    title: str = typer.Option("Code review request", "--title", "-t", help="Review bundle title"),
+    context: Optional[str] = typer.Option(None, "--context", help="Rationale/context to include in the bundle"),
+    context_file: Optional[Path] = typer.Option(None, "--context-file", help="Markdown/text file with rationale/context"),
+    decision: Optional[str] = typer.Option(None, "--decision", help="Specific decision the reviewer should answer"),
+    expected_contract: Optional[list[str]] = typer.Option(
+        None,
+        "--expected-contract",
+        help="Expected invariant/contract for the implementation (repeatable)",
+    ),
+    expected_contract_file: Optional[Path] = typer.Option(None, "--expected-contract-file", help="File containing expected invariants/contracts"),
+    prior_critique: Optional[list[str]] = typer.Option(
+        None,
+        "--prior-critique",
+        help="Prior finding/risk the reviewer should re-check (repeatable)",
+    ),
+    prior_critique_file: Optional[Path] = typer.Option(None, "--prior-critique-file", help="File containing prior critique to re-check"),
+    non_goals: Optional[list[str]] = typer.Option(
+        None,
+        "--non-goal",
+        help="Topic the reviewer should explicitly avoid (repeatable)",
+    ),
+    non_goals_file: Optional[Path] = typer.Option(None, "--non-goals-file", help="File containing review non-goals"),
+    include_required_output_format: bool = typer.Option(
+        True,
+        "--required-output-format/--no-required-output-format",
+        help="Include a strict merge-gate output schema",
+    ),
+    review_files: Optional[list[Path]] = typer.Option(
+        None,
+        "--review-file",
+        "-R",
+        help="Specific file to include in the review scope (repeatable)",
+    ),
+    all_changed: bool = typer.Option(False, "--all-changed", help="Include every changed file in diff/status/content scope"),
+    include_diff: bool = typer.Option(True, "--diff/--no-diff", help="Include current git diff"),
+    include_file_contents: bool = typer.Option(False, "--file-contents/--no-file-contents", help="Include selected changed file contents"),
+    max_diff_chars: int = typer.Option(DEFAULT_MAX_DIFF_CHARS, "--max-diff-chars", help="Maximum diff characters to include"),
+    max_file_chars: int = typer.Option(DEFAULT_MAX_FILE_CHARS, "--max-file-chars", help="Maximum characters per changed file"),
+    skip_git_check: bool = typer.Option(False, "--skip-git-check", help="Skip git status verification"),
+    clipboard: bool = typer.Option(True, "--clipboard/--no-clipboard", "-c", help="Copy bundle to clipboard with xclip"),
+    require_clipboard: bool = typer.Option(False, "--require-clipboard", help="Fail if xclip copy fails"),
+) -> None:
+    """Create a complete markdown review bundle in /tmp and optionally copy it with xclip.
 
     Examples:
-        # Find all review files
-        code_review.py find
+        # Bundle a targeted review scope into /tmp and copy with xclip
+        code_review.py bundle --context "Runtime status protocol changes" -R src/runtime.py -R tests/test_runtime.py
+
+        # State intended behavior explicitly so the reviewer does not infer it
+        code_review.py bundle -R src/runtime.py --decision "Is this safe to merge?" \
+          --expected-contract "Plain ask degrades if artifacts are unwritable" \
+          --prior-critique "Prune must not delete unrelated directories" \
+          --non-goal "Do not review generated artifacts"
 
-        # Find in specific directory
-        code_review.py find --dir ./reviews --pattern "*.md"
+        # Include an existing request file
+        code_review.py bundle --file request.md --repo-dir /path/to/repo -R src/runtime.py
 
-        # Find files containing specific text
-        code_review.py find --contains "Repository and branch"
+        # Write to a specific file without clipboard
+        code_review.py bundle --output /tmp/review.md --no-clipboard
 
-        # Find recent files, sorted by modification time
-        code_review.py find --sort modified --limit 10
+        # Explicitly include all changed files when that broad scope is intentional
+        code_review.py bundle --all-changed --file-contents
 
-        # Non-recursive search
-        code_review.py find --no-recursive
+        # Skip git warning/check output
+        code_review.py bundle --file request.md --skip-git-check
     """
-    if not directory.exists():
-        typer.echo(f"Error: Directory not found: {directory}", err=True)
-        raise typer.Exit(code=1)
+    repo_root = _resolve_repo_dir(repo_dir)
+    request_content = _read_optional_file(file, "request file")
+    rationale = _read_context(context, context_file)
+    expected_contract_content = _read_list_section(expected_contract, expected_contract_file, "expected contract file")
+    prior_critique_content = _read_list_section(prior_critique, prior_critique_file, "prior critique file")
+    non_goals_content = _read_list_section(non_goals, non_goals_file, "non-goals file")
+    selected_paths = _normalize_review_files(repo_root, review_files)
+    scope_paths = [] if all_changed else selected_paths
+
+    if not skip_git_check:
+        git_status = check_git_status(repo_root)
 
-    # Collect matching files
-    matches = []
-    search_paths = directory.rglob(pattern) if recursive else directory.glob(pattern)
+        typer.echo("--- Git Status Check ---", err=True)
+        typer.echo(f"Branch: {git_status['current_branch'] or 'unknown'}", err=True)
+        typer.echo(f"Remote: {git_status['remote_branch'] or 'not tracking'}", err=True)
 
-    for path in search_paths:
-        if not path.is_file():
-            continue
+        if git_status["has_uncommitted"]:
+            typer.echo("Note: Uncommitted changes detected; bundle will include local diff/context.", err=True)
 
-        # Content filter
-        if contains:
-            try:
-                content = path.read_text(errors="ignore")
-                if contains.lower() not in content.lower():
-                    continue
-            except Exception:
-                continue
+        if git_status["has_unpushed"]:
+            typer.echo("Note: Unpushed commits detected; external web tools may not see them unless included here.", err=True)
 
-        try:
-            stat = path.stat()
-            matches.append({
-                "path": str(path),
-                "name": path.name,
-                "size": stat.st_size,
-                "modified": stat.st_mtime,
-                "modified_str": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
-            })
-        except Exception:
-            continue
+        if not git_status["has_uncommitted"] and not git_status["has_unpushed"]:
+            typer.echo("OK: All changes committed and pushed", err=True)
+
+        typer.echo("------------------------", err=True)
+
+    bundle_content = _build_review_bundle(
+        title=title,
+        request_content=request_content,
+        repo_dir=repo_root,
+        git_metadata=_collect_git_metadata(repo_root, scope_paths, all_changed),
+        rationale=rationale,
+        decision=decision.strip() if decision else "",
+        expected_contract=expected_contract_content,
+        prior_critique=prior_critique_content,
+        non_goals=non_goals_content,
+        include_required_output_format=include_required_output_format,
+        include_diff=include_diff,
+        include_file_contents=include_file_contents,
+        selected_paths=selected_paths,
+        all_changed=all_changed,
+        max_diff_chars=max_diff_chars,
+        max_file_chars=max_file_chars,
+    )
+
+    output_path = output or _default_output_path(output_dir)
+    output_path.parent.mkdir(parents=True, exist_ok=True)
+    output_path.write_text(bundle_content)
+    typer.echo(f"Wrote review bundle to {output_path}", err=True)
+
+    if clipboard:
+        _copy_to_clipboard(bundle_content, require_clipboard)
 
-    # Sort results
-    if sort_by == "modified":
-        matches.sort(key=lambda x: x["modified"], reverse=True)
-    elif sort_by == "name":
-        matches.sort(key=lambda x: x["name"].lower())
-    elif sort_by == "size":
-        matches.sort(key=lambda x: x["size"], reverse=True)
-
-    # Limit results
-    matches = matches[:limit]
-
-    if not matches:
-        typer.echo(f"No files matching '{pattern}' found in {directory}", err=True)
-        raise typer.Exit(code=0)
-
-    # Output
-    typer.echo(f"Found {len(matches)} file(s):\n", err=True)
-    for m in matches:
-        size_kb = m["size"] / 1024
-        typer.echo(f"  {m['modified_str']}  {size_kb:6.1f}KB  {m['path']}", err=True)
-
-    # JSON output
-    print(json.dumps({
-        "pattern": pattern,
-        "directory": str(directory),
-        "count": len(matches),
-        "files": matches,
-    }, indent=2))
+    print(str(output_path))
diff --git a/skills/review-code/commands/find.py b/skills/review-code/commands/find.py
new file mode 100644
index 00000000..e104c6dc
--- /dev/null
+++ b/skills/review-code/commands/find.py
@@ -0,0 +1,72 @@
+"""Find command for code-review skill."""
+from __future__ import annotations
+
+import json
+from datetime import datetime
+from pathlib import Path
+from typing import Optional
+
+import typer
+
+
+def find(
+    pattern: str = typer.Option("*review*.md", "--pattern", "-p", help="Glob pattern for filenames"),
+    directory: Path = typer.Option(".", "--dir", "-d", help="Directory to search"),
+    recursive: bool = typer.Option(True, "--recursive/--no-recursive", "-r", help="Search recursively"),
+    limit: int = typer.Option(20, "--limit", "-l", help="Maximum results to show"),
+    sort_by: str = typer.Option("modified", "--sort", "-s", help="Sort by: modified, name, size"),
+    contains: Optional[str] = typer.Option(None, "--contains", "-c", help="Filter by content substring"),
+) -> None:
+    """Find review request markdown files."""
+    if not directory.exists():
+        typer.echo(f"Error: Directory not found: {directory}", err=True)
+        raise typer.Exit(code=1)
+
+    matches = []
+    search_paths = directory.rglob(pattern) if recursive else directory.glob(pattern)
+
+    for path in search_paths:
+        if not path.is_file():
+            continue
+        if contains:
+            try:
+                content = path.read_text(errors="ignore")
+                if contains.lower() not in content.lower():
+                    continue
+            except Exception:
+                continue
+        try:
+            stat = path.stat()
+        except Exception:
+            continue
+        matches.append({
+            "path": str(path),
+            "name": path.name,
+            "size": stat.st_size,
+            "modified": stat.st_mtime,
+            "modified_str": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
+        })
+
+    if sort_by == "modified":
+        matches.sort(key=lambda item: item["modified"], reverse=True)
+    elif sort_by == "name":
+        matches.sort(key=lambda item: item["name"].lower())
+    elif sort_by == "size":
+        matches.sort(key=lambda item: item["size"], reverse=True)
+
+    matches = matches[:limit]
+    if not matches:
+        typer.echo(f"No files matching '{pattern}' found in {directory}", err=True)
+        raise typer.Exit(code=0)
+
+    typer.echo(f"Found {len(matches)} file(s):\n", err=True)
+    for match in matches:
+        size_kb = match["size"] / 1024
+        typer.echo(f"  {match['modified_str']}  {size_kb:6.1f}KB  {match['path']}", err=True)
+
+    print(json.dumps({
+        "pattern": pattern,
+        "directory": str(directory),
+        "count": len(matches),
+        "files": matches,
+    }, indent=2))
```

## Required Output Format

# Merge-blocking findings

## High severity

### H1. <title>
- Evidence:
- Impact:
- Exact fix:
- Test that should fail before the fix:

## Medium severity

Only include if it should block merge or materially affect runtime safety.

# Important test gaps

List only tests required before merge.

# Merge recommendation

Use exactly one:
- SAFE_TO_MERGE
- SAFE_WITH_CONDITIONS
- CHANGES_REQUESTED
- NOT_SAFE
