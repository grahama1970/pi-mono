# Design Brief

Adapt the reference_dashboard.html into a SPARTA Posture Dashboard. Keep the SAME layout quality, interactivity, SVG charts, filters, and structure. Replace the data domain:

- Business Units → Datalake scope (SPARTA / F-36 / Both)  
- NIST CSF Functions → NIST 800-53 Control Families (AC, AU, CA, CM, IA, IR, MA, MP, PE, PL, PS, RA, SA, SC, SI)
- Vulnerability severity bars → NRS distribution (accept >=0.8 / uncertain 0.6-0.8 / reject <0.6)
- Framework filter → 8 frameworks: SPARTA, NIST, CWE, ATT&CK, D3FEND, ESA, ISO, NASA
- Patch SLA → QRA Coverage %
- Open Vulnerabilities → Gap Count
- Top Risk Domains → Top 10 Risk Controls (control_id, name, framework, NRS, weaknesses)
- Add drift alerts section
- Add row of 8 donut rings for framework coverage

THEME: EMBRY dark (bg=#0d0f12, card=#12151a, green=#00ff88, amber=#ffaa00, red=#ff4444, blue=#4a9eff, accent=#7c4dff, white=#e8eaed). Space Mono font.
