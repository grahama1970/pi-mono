# Design Brief

SPARTA Posture Dashboard — compliance officer view for Authorizing Official. Dark EMBRY theme (bg=#0d0f12, card=#12151a, green=#00ff88, amber=#ffaa00, red=#ff4444, blue=#4a9eff, white=#e8eaed). Layout: Row 1: Large posture score (72%) with delta badge, 8 small donut charts per framework. Row 2: NIST 800-53 family horizontal stacked bars (AC-SI, pass=green/partial=amber/fail=red), gap analysis card. Row 3: drift alerts list, top 10 risk controls table. Monospace fonts, uppercase labels, glow dots.
