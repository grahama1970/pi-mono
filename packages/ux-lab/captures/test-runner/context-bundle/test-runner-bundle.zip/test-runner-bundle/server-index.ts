import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import cors from "cors";
import { readdir, readFile, stat } from "fs/promises";
import { request as httpRequest, createServer as createHttpServer } from "http";
import { WebSocketServer, WebSocket } from "ws";

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3001');
  const httpServer = createHttpServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  app.use(cors());
  app.use(express.json());

  // Mock screenshot endpoint
  app.get('/api/projects/:id/screenshot', async (req, res) => {
    // In a real app, this would use puppeteer or similar to capture the live site
    // For now, we'll return a placeholder or the first mockup as a "live" version
    try {
      const stitchPath = path.resolve(process.cwd(), `captures/${req.params.id}/stitch`);
      const files = await readdir(stitchPath);
      const firstPng = files.find(f => f.endsWith('.png'));
      if (firstPng) {
        res.sendFile(path.join(stitchPath, firstPng));
      } else {
        res.status(404).send('No screenshot available');
      }
    } catch (e) {
      res.status(404).send('No screenshot available');
    }
  });

  // WebSocket Broadcast Relay
  wss.on('connection', (ws) => {
    console.log('[WS] Client connected');
    ws.on('message', (data) => {
      const message = data.toString();
      // Broadcast to all other clients
      wss.clients.forEach((client) => {
        if (client !== ws && client.readyState === WebSocket.OPEN) {
          client.send(message);
        }
      });
    });
  });

  // Memory Daemon Proxy (Unix Socket)
  const MEMORY_SOCKET = '/run/user/1000/embry/memory.sock';

  function memoryRequest(method: string, path: string, body?: object): Promise<any> {
    return new Promise((resolve, reject) => {
      const opts = {
        socketPath: MEMORY_SOCKET,
        method,
        path,
        headers: { 'Content-Type': 'application/json' },
      };
      const req = httpRequest(opts, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            resolve({ error: 'PARSE_ERROR', raw: data });
          }
        });
      });
      req.on('error', (err) => {
        console.error('[MEMORY] Request failed:', err.message);
        reject(err);
      });
      if (body) req.write(JSON.stringify(body));
      req.end();
    });
  }

  // Memory daemon proxy — individual routes for each endpoint
  const memoryProxy = async (req: express.Request, res: express.Response) => {
    const subPath = req.path.replace('/api/memory', '');
    try {
      const result = await memoryRequest(req.method, subPath || '/', req.body);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: 'MEMORY_DAEMON_OFFLINE', message: err.message });
    }
  };
  app.post('/api/memory/recall', memoryProxy);
  app.post('/api/memory/learn', memoryProxy);
  app.post('/api/memory/list', memoryProxy);
  app.post('/api/memory/clarify', memoryProxy);
  app.post('/api/memory/intent', memoryProxy);
  app.post('/api/memory/store', memoryProxy);
  app.get('/api/memory/health', memoryProxy);
  app.post('/api/memory/taxonomy/extract', memoryProxy);
  app.post('/api/memory/analytics/run', memoryProxy);

  // scillm Proxy
  app.post('/api/scillm', async (req, res) => {
    const opts = {
      hostname: 'localhost',
      port: 4001,
      path: '/v1/chat/completions',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer sk-dev-proxy-123'
      },
    };
    const proxyReq = httpRequest(opts, (proxyRes) => {
      res.status(proxyRes.statusCode || 200);
      proxyRes.pipe(res);
    });
    proxyReq.on('error', (err) => {
      res.status(500).json({ error: 'SCILLM_OFFLINE', message: err.message });
    });
    proxyReq.write(JSON.stringify(req.body));
    proxyReq.end();
  });

  // Serve captures as static files
  app.use('/captures', express.static(path.resolve(process.cwd(), 'captures')));

  // List projects (scan captures directory)
  app.get('/api/projects', async (req, res) => {
    try {
      const capturesPath = path.resolve(process.cwd(), 'captures');
      const dirs = await readdir(capturesPath);
      const projects = await Promise.all(dirs.map(async (dir) => {
        const dirPath = path.join(capturesPath, dir);
        const s = await stat(dirPath);
        if (!s.isDirectory()) return null;
        
        // Try to find a thumbnail in stitch folder
        let thumbnail = null;
        try {
          const stitchPath = path.join(dirPath, 'stitch');
          const stitchFiles = await readdir(stitchPath);
          const firstPng = stitchFiles.find(f => f.endsWith('.png'));
          if (firstPng) {
            thumbnail = `/captures/${dir}/stitch/${firstPng}`;
          }
        } catch (e) {
          // No stitch folder or no pngs
        }

        return {
          id: dir,
          title: dir.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
          subtitle: `(${dir})`,
          date: s.mtime.toLocaleDateString(),
          type: 'desktop',
          thumbnail
        };
      }));
      res.json(projects.filter(Boolean));
    } catch (err) {
      res.json([]);
    }
  });

  // Run test interactions
  app.post('/api/projects/:id/test-interactions', async (req, res) => {
    const { id } = req.params;
    console.log(`[TEST] Running interactions for project: ${id}`);
    
    // Simulate real interaction steps
    const steps = [
      { msg: `[INIT] STARTING_TEST_SUITE: ${id}`, node: null },
      { msg: '[TEST] CLICK: Button#deploy_btn', node: 'btn_01' },
      { msg: '[TEST] HOVER: Card#project_01', node: 'crd_03' },
      { msg: '[TEST] PAN: DesignBoard (X: +200, Y: -150)', node: null },
      { msg: '[TEST] INPUT: Search#main_query', node: 'inp_02' },
      { msg: '[OK] INTERACTION_SUCCESS: Latency 4ms', node: null },
      { msg: '[VLM] VALIDATING_VISUAL_STATE...', node: 'crd_03' },
      { msg: '[WARN] VISUAL_MISMATCH_DETECTED: Expected 0.98, Got 0.92', node: 'crd_03', status: 'INCONCLUSIVE' },
    ];

    res.json({ success: true, steps });
  });

  // Primary mockup image endpoint
  app.get('/api/projects/:id/mockup-primary', async (req, res) => {
    try {
      const stitchPath = path.resolve(process.cwd(), `captures/${req.params.id}/stitch`);
      const files = await readdir(stitchPath);
      const firstPng = files.find(f => f.endsWith('.png'));
      if (firstPng) {
        res.sendFile(path.join(stitchPath, firstPng));
      } else {
        res.status(404).send('No mockup available');
      }
    } catch (e) {
      res.status(404).send('No mockup available');
    }
  });

  // Design board data for a project
  app.get('/api/projects/:id/design-board', async (req, res) => {
    try {
      const captureDir = path.resolve(process.cwd(), `captures/${req.params.id}`);
      const files = await readdir(captureDir);

      // Find DESIGN_BOARD.md
      const hasMd = files.includes('DESIGN_BOARD.md');
      let markdown: string | null = null;
      if (hasMd) {
        markdown = await readFile(path.join(captureDir, 'DESIGN_BOARD.md'), 'utf-8');
      }

      // Find round composite PNGs (round_01_*.png, round_02_*.png etc)
      const rounds = files
        .filter(f => /^round_\d+.*\.png$/i.test(f))
        .sort()
        .map(f => ({
          name: f.replace('.png', '').replace(/_/g, ' '),
          src: `/captures/${req.params.id}/${f}`,
        }));

      // Find Gemini design board HTML files
      const htmlBoards = files
        .filter(f => /design-board.*\.html$/i.test(f) || /mockup.*\.html$/i.test(f))
        .sort()
        .map(f => ({
          name: f.replace('.html', ''),
          src: `/captures/${req.params.id}/${f}`,
        }));

      // Find stitch mockups if they exist
      let stitchImages: { name: string; src: string }[] = [];
      try {
        const stitchPath = path.join(captureDir, 'stitch');
        const stitchFiles = await readdir(stitchPath);
        stitchImages = stitchFiles
          .filter(f => f.endsWith('.png'))
          .map(f => ({
            name: f.replace('.png', ''),
            src: `/captures/${req.params.id}/stitch/${f}`,
          }));
      } catch (_) { /* no stitch dir */ }

      res.json({
        hasMarkdown: hasMd,
        markdown,
        rounds,
        htmlBoards,
        stitchImages,
      });
    } catch (err) {
      res.json({ hasMarkdown: false, markdown: null, rounds: [], htmlBoards: [], stitchImages: [] });
    }
  });

  // List mockups for a project
  app.get('/api/projects/:id/mockups', async (req, res) => {
    try {
      const stitchPath = path.resolve(process.cwd(), `captures/${req.params.id}/stitch`);
      const files = await readdir(stitchPath);
      const mockups = files
        .filter(f => f.endsWith('.png'))
        .map(f => ({
          id: f.replace('.png', ''),
          name: f.replace('.png', '').toUpperCase(),
          thumbnail: `/captures/${req.params.id}/stitch/${f}`,
          type: 'MOCKUP'
        }));
      res.json(mockups);
    } catch (err) {
      res.json([]);
    }
  });

  // List components for a project
  app.get('/api/projects/:id/components', async (req, res) => {
    try {
      const componentsDir = path.resolve(process.cwd(), `src/components/${req.params.id}`);
      const files = await readdir(componentsDir);
      const components = await Promise.all(files
        .filter(f => f.endsWith('.tsx'))
        .map(async (f) => {
          const content = await readFile(path.join(componentsDir, f), 'utf-8');
          const lineCount = content.split('\n').length;
          return {
            name: f.replace('.tsx', ''),
            lines: lineCount,
            status: 'COMMITTED'
          };
        }));
      res.json(components);
    } catch (err) {
      res.json([]);
    }
  });

  // Pipeline status
  app.get('/api/pipeline/status', async (req, res) => {
    try {
      const results = await readFile(path.resolve(process.cwd(), 'pipeline_results.json'), 'utf-8');
      res.json(JSON.parse(results));
    } catch (err) {
      res.status(404).json({ error: 'PIPELINE_RESULTS_NOT_FOUND' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Tactical Server running on http://localhost:${PORT}`);
  });
}

startServer();
